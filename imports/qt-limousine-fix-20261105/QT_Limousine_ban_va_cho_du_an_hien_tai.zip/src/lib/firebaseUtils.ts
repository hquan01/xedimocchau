import { doc, setDoc, deleteDoc, collection, query, where, onSnapshot, orderBy, runTransaction } from "firebase/firestore";
import { db, auth, handleFirestoreError, OperationType } from "../firebase";
import { Booking, User, BlockedSeat, LimousineConfig, SharedCarConfig, TourCombo, Accommodation, Coupon, LocationPoint, Destination, GuideArticle, AppNotification, Review, ZaloGroup, CommunityQuestion } from "../types";

// Let's get things from localStorage
export const getDeviceId = (): string => {
  let id = localStorage.getItem("xemc_device_id");
  if (!id) {
    id = "dev_" + Math.random().toString(36).substring(2, 15);
    localStorage.setItem("xemc_device_id", id);
  }
  return id;
};

export const getLocalList = <T>(key: string, defaultValue: T[]): T[] => {
  try {
    const val = localStorage.getItem(`xemc_${key}`);
    return val ? JSON.parse(val) : defaultValue;
  } catch (e) {
    return defaultValue;
  }
};

export const setLocalList = <T>(key: string, data: T[]) => {
  try {
    localStorage.setItem(`xemc_${key}`, JSON.stringify(data));
    window.dispatchEvent(new Event("xedimocchau_db_update"));
  } catch (e) {
    console.error(e);
  }
};

export const saveReviewToFirebase = async (review: Review) => {
  try {
    const sanitizedReview = JSON.parse(JSON.stringify(review));
    await setDoc(doc(db, "reviews", review.id), sanitizedReview);
    console.log("Review saved to Firebase successfully");
  } catch (error) {
    console.error("Error saving review to Firebase:", error);
    throw error;
  }
};

export const deleteReviewFromFirebase = async (id: string) => {
  try {
    await deleteDoc(doc(db, "reviews", id));
    console.log("Review deleted from Firebase successfully");
  } catch (error) {
    console.error("Error deleting review from Firebase:", error);
    throw error;
  }
};

export const listenToReviews = (destinationId: string, callback: (reviews: Review[]) => void) => {
  const q = query(
    collection(db, "reviews"),
    where("destinationId", "==", destinationId)
  );

  return onSnapshot(q, (snapshot) => {
    const reviews: Review[] = [];
    snapshot.forEach((doc) => {
      reviews.push(doc.data() as Review);
    });
    // Sort on client side to avoid index requirement
    reviews.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    callback(reviews);
  }, (error) => {
    console.error("Error listening to reviews:", error);
  });
};

export const saveBookingToFirebase = async (booking: Booking) => {
  // A saved booking must be acknowledged by Firebase before the deposit modal opens.
  const sanitized = JSON.parse(JSON.stringify(booking));
  sanitized.deviceId = getDeviceId();
  if(!sanitized.userId)sanitized.userId = '';
  const bookingRef=doc(db,'bookings',booking.id);
  const pointsToSpend=Math.max(0,Math.floor(Number(booking.pointsDeducted||0)));
  const couponCode=typeof booking.couponCode==='string'?booking.couponCode.trim().toUpperCase():'';
  try {
    if(pointsToSpend>0 || couponCode) {
      const uid=auth.currentUser?.uid;
      if(!uid || booking.userId!==uid)throw new Error('Cần đăng nhập hội viên để dùng điểm hoặc voucher.');
      const profileRef=doc(db,'users',uid);
      await runTransaction(db,async tx=>{
        const [profileDoc,bookingDoc] = await Promise.all([tx.get(profileRef),tx.get(bookingRef)]);
        if(bookingDoc.exists())throw new Error('Mã đặt vé đã tồn tại, vui lòng kiểm tra lại.');
        if(!profileDoc.exists())throw new Error('Không tìm thấy ví điểm hội viên.');
        const profile=profileDoc.data() as User;
        const prior=Number(profile.completedBookingsCount||0) || (profile.rewardedBookingIds||[]).length;
        if(prior < 1)throw new Error('Điểm và voucher chỉ sử dụng từ lần đặt vé thứ hai.');
        const balance=Math.max(0,Number(profile.points||0));
        if(pointsToSpend>balance)throw new Error('Số dư điểm không đủ.');
        const used=Array.isArray(profile.usedCoupons)?profile.usedCoupons:[];
        if(couponCode && used.includes(couponCode))throw new Error('Voucher đã dùng.');
        // Voucher pricing must still be verified by Admin at confirmation.
        const changes:any={};
        if(pointsToSpend>0)changes.points=balance-pointsToSpend;
        if(couponCode)changes.usedCoupons=[...used,couponCode];
        tx.update(profileRef,changes);
        tx.set(bookingRef,sanitized);
      });
    } else {
      await setDoc(bookingRef,sanitized);
    }
    const existing=getLocalList<Booking>('bookings',[]);
    setLocalList('bookings',[...existing.filter(b=>b.id!==booking.id),sanitized]);
  } catch(error:any) {
    console.error('Booking NOT saved:',error);
    throw new Error(error?.message || 'Chưa lưu được đơn đặt vé lên Firebase. Không chuyển khoản khi chưa có mã đơn.');
  }
};

export const updateStatusInFirebase = async (id: string, data: any, collectionName: string = 'bookings') => {
  const sanitizedData = JSON.parse(JSON.stringify(data));
  try {
    await setDoc(doc(db, collectionName, id), sanitizedData, { merge: true });
  } catch (error) {
    console.error(`Firestore update failed: ${collectionName}/${id}`, error);
    throw error;
  }
  if (collectionName === 'bookings') {
    const current = getLocalList<Booking>('bookings', []);
    const idx = current.findIndex(b=>b.id===id);
    if (idx >= 0) {
      current[idx] = {...current[idx],...data};
      setLocalList('bookings',current);
    }
  }
};

export const updateBookingStatusInFirebase = async (id: string, booking: Booking) =>
  updateStatusInFirebase(id, booking, 'bookings');

/** Admin-only status +1-point reward, idempotent on booking ID. */
export async function updateBookingStatusWithRewards(bookingId:string,status:Booking['status']):Promise<void> {
  const ref=doc(db,'bookings',bookingId);
  await runTransaction(db,async transaction=>{
    const snapshot=await transaction.get(ref);
    if(!snapshot.exists())throw new Error('Không tìm thấy đơn đặt vé.');
    const booking=snapshot.data() as Booking;
    const profileRef=booking.userId?doc(db,'users',booking.userId):null;
    const profileSnap=profileRef?await transaction.get(profileRef):null;
    if(profileRef && profileSnap?.exists() && (status==='success'||status==='completed')) {
      const profile=profileSnap.data() as User;
      const rewarded=Array.isArray(profile.rewardedBookingIds)?profile.rewardedBookingIds:[];
      if(!rewarded.includes(bookingId)){
        transaction.update(profileRef,{
          points:Math.max(0,Number(profile.points||0))+1,
          rewardedBookingIds:[...rewarded,bookingId],
          completedBookingsCount:Math.max(0,Number(profile.completedBookingsCount||0))+1
        });
      }
    }
    transaction.update(ref,{status});
  });
}

export const deleteBookingFromFirebase = async (bookingId: string) => {
  await deleteDoc(doc(db,'bookings',bookingId));
  setLocalList('bookings',getLocalList<Booking>('bookings',[]).filter(b=>b.id!==bookingId));
};

export const saveBlockedSeatToFirebase = async (seat: BlockedSeat) => {
  const key = seat.seatId + seat.tripId + seat.travelDate;
  const current = getLocalList<BlockedSeat>("blocked_seats", []);
  const idx = current.findIndex(s => s.tripId === seat.tripId && s.travelDate === seat.travelDate && s.seatId === seat.seatId);
  if (idx > -1) {
    current[idx] = seat;
  } else {
    current.push(seat);
  }
  setLocalList("blocked_seats", current);

  if (true) {
    try {
      await setDoc(doc(db, "blocked_seats", key), seat);
    } catch (error) {
      console.warn("Could not save blocked seat to Firebase, saved locally:", error);
    }
  }
};

export const deleteBlockedSeatFromFirebase = async (seat: BlockedSeat) => {
  const key = seat.seatId + seat.tripId + seat.travelDate;
  const current = getLocalList<BlockedSeat>("blocked_seats", []);
  const nextList = current.filter(s => !(s.seatId === seat.seatId && s.tripId === seat.tripId && s.travelDate === seat.travelDate));
  setLocalList("blocked_seats", nextList);

  if (true) {
    try {
      await deleteDoc(doc(db, "blocked_seats", key));
    } catch (error) {
      console.warn("Could not delete blocked seat from Firebase, removed locally:", error);
    }
  }
};

export const saveConfigToFirebase = async (key: string, data: any) => {
  // Split storage: Save each key into its own document or collection
  try {
    const sanitizedData = JSON.parse(JSON.stringify(data));
    
    // Helper function for collection batch update
    const updateCollection = async (collectionName: string, items: any[]) => {
      const { writeBatch, collection, doc, getDocs } = await import("firebase/firestore");
      const existingDocs = await getDocs(collection(db, collectionName));
      const currentIds = new Set(items.map(i => i.id));
      
      const batch = writeBatch(db);
      // Delete removed items
      existingDocs.docs.forEach(docSnap => {
        if (!currentIds.has(docSnap.id)) batch.delete(docSnap.ref);
      });
      // Upsert current items
      items.forEach((item: any) => {
        if (!item.id) {
           console.warn(`Item in ${collectionName} missing ID, skipping:`, item);
           return;
        }
        const ref = doc(collection(db, collectionName), String(item.id));
        batch.set(ref, item);
      });
      await batch.commit();
      console.log(`Collection ${collectionName} updated successfully`);
    };

    if (key === "combos" && Array.isArray(sanitizedData)) {
       await updateCollection("tour_combos", sanitizedData);
    } else if (key === "accommodations" && Array.isArray(sanitizedData)) {
       await updateCollection("accommodations", sanitizedData);
    } else if (key === "articles" && Array.isArray(sanitizedData)) {
       await updateCollection("guide_articles", sanitizedData);
    } else if (key === "coupons" && Array.isArray(sanitizedData)) {
       await updateCollection("coupons", sanitizedData);
    } else if (key === "destinations" && Array.isArray(sanitizedData)) {
       await updateCollection("destinations", sanitizedData);
    } else {
       // Save smaller configs to its own document (e.g., configs/limousineConfig)
       await setDoc(doc(db, "configs", key), { [key]: sanitizedData });
       console.log(`Config ${key} saved to Firestore successfully`);
    }
  } catch (error: any) {
    console.error(`ERROR: Could not save config ${key} to Firebase:`, error);
    if (error.code === 'permission-denied') {
       alert(`Lỗi: Bạn không có quyền sửa nội dung này trên máy chủ (Permission Denied).`);
    } else {
       alert(`Lỗi khi lưu ${key} lên máy chủ: ${error.message || 'Lỗi mạng'}. Không cập nhật dữ liệu trên máy.`);
    }
    throw error;
  }
  // Cache is updated only after the cloud write succeeded.
  const configs = JSON.parse(localStorage.getItem('xemc_configs') || '{}');
  configs[key] = data;
  localStorage.setItem('xemc_configs',JSON.stringify(configs));
  window.dispatchEvent(new Event('xedimocchau_db_update'));
};

export const saveUserToFirebase = async (userId: string, data: any) => {
  // Never write role, wallet, email credentials or plaintext passwords from UI.
  const {name, phone, address, favPickup, favDropoff} = data;
  await setDoc(doc(db,'users',userId),{name,phone,address:address||'',favPickup:favPickup||'',favDropoff:favDropoff||''},{merge:true});
  const list = getLocalList<any>('users',[]);
  const record = {id:userId,name,phone,address,favPickup,favDropoff};
  const index=list.findIndex(u=>u.id===userId);
  if(index>=0)list[index]={...list[index],...record};else list.push(record);
  setLocalList('users',list);
};

export const saveNotificationToFirebase = async (notification: AppNotification) => {
  const sanitized = JSON.parse(JSON.stringify(notification));
  await setDoc(doc(db,'notifications',notification.id),sanitized);
};

export const saveZaloGroupToFirebase = async (group: ZaloGroup) => {
  const sanitized=JSON.parse(JSON.stringify(group));
  try { await setDoc(doc(db,'zalo_groups',group.id),sanitized,{merge:true}); }
  catch(error){alert('Lưu nhóm Zalo thất bại. Kiểm tra quyền Admin và Firebase.');throw error;}
  const list=getLocalList<ZaloGroup>('zalo_groups',[]);
  setLocalList('zalo_groups',[...list.filter(g=>g.id!==group.id),group]);
};
export const deleteZaloGroupFromFirebase = async (id: string) => {
  try { await deleteDoc(doc(db,'zalo_groups',id)); }
  catch(error){alert('Xóa nhóm Zalo thất bại. Kiểm tra quyền Admin và Firebase.');throw error;}
  setLocalList('zalo_groups',getLocalList<ZaloGroup>('zalo_groups',[]).filter(g=>g.id!==id));
};

export const saveCommunityQuestionToFirebase = async (question: CommunityQuestion) => {
  const current = getLocalList<CommunityQuestion>("community_questions", []);
  const existingIdx = current.findIndex(q => q.id === question.id);
  if (existingIdx > -1) {
    current[existingIdx] = question;
  } else {
    current.push(question);
  }
  setLocalList("community_questions", current);

  try {
    const sanitized = JSON.parse(JSON.stringify(question));
    await setDoc(doc(db, "community_posts", question.id), sanitized, { merge: true });
    console.log(`Community question ${question.id} saved to Firestore`);
  } catch (err) {
    console.warn("Could not save community_post to Firestore, saved locally:", err);
  }
};

