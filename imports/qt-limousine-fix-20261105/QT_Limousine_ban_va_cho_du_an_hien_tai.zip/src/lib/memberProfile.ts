import type { User as FirebaseAuthUser } from 'firebase/auth';
import { doc, runTransaction } from 'firebase/firestore';
import { db } from '../firebase';
import type { User } from '../types';

/** New accounts only. No backfill for old accounts without verified history. */
export async function ensureMemberProfile(account: FirebaseAuthUser, isAdmin = false, preferredName = '', preferredPhone = ''): Promise<User> {
  const memberRef = doc(db, 'users', account.uid);
  return runTransaction(db, async transaction => {
    const snapshot = await transaction.get(memberRef);
    const existing = snapshot.exists() ? snapshot.data() : null;
    if (!existing) {
      const profile: User = {
        id: account.uid,
        email: account.email || '',
        name: preferredName || account.displayName || account.email || 'Thành viên',
        phone: preferredPhone || account.phoneNumber || '',
        points: isAdmin ? 0 : 10,
        role: 'customer',
        ...(!isAdmin ? {welcomeBonusGranted:true, welcomeBonusPoints:10, welcomeBonusAt:new Date().toISOString()} : {})
      };
      transaction.set(memberRef,{ ...profile,createdAt:new Date().toISOString() });
      return {...profile,role:isAdmin ? 'operator' : 'customer'};
    }
    const profile: User = {
      ...(existing as User),
      id: account.uid,
      email: account.email || existing.email || '',
      name: preferredName || existing.name || account.displayName || 'Thành viên',
      phone: preferredPhone || existing.phone || '',
      points: Number(existing.points || 0),
      role: isAdmin ? 'operator' : 'customer'
    };
    const changes: Record<string,string> = {};
    if (preferredName && preferredName !== existing.name) changes.name = preferredName;
    if (preferredPhone && preferredPhone !== existing.phone) changes.phone = preferredPhone;
    if (Object.keys(changes).length) transaction.update(memberRef, changes);
    return profile;
  });
}
