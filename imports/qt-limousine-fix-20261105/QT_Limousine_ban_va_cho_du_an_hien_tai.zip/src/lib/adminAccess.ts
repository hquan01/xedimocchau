import type { IdTokenResult } from 'firebase/auth';

// Legacy owner fallback: verified Firebase identity only. Migrate to server-side
// Firebase custom claims (admin/operator) before adding other operators.
export const OWNER_EMAILS = ['hquansl001@gmail.com', 'nhaxe@mocchau.vn'];
export function hasOperatorAccess(token: IdTokenResult | null | undefined): boolean {
  if (!token) return false;
  if (token.claims.admin === true || token.claims.operator === true) return true;
  const email = String(token.claims.email || '').trim().toLowerCase();
  return token.claims.email_verified === true && OWNER_EMAILS.includes(email);
}
