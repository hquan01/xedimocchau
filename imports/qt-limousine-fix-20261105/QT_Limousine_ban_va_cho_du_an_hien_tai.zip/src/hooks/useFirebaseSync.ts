import { useState, useEffect } from "react";
import { collection, doc, onSnapshot, getDocs, setDoc, query, where } from "firebase/firestore";
import { onAuthStateChanged } from "firebase/auth";
import { hasOperatorAccess } from "../lib/adminAccess";
import { ensureMemberProfile } from "../lib/memberProfile";
import { db, auth, handleFirestoreError, OperationType } from "../firebase";
import { Booking, BlockedSeat, User, AppNotification, LimousineConfig, SharedCarConfig, TourCombo, Accommodation, Coupon, LocationPoint, Destination, GuideArticle, Driver, ZaloGroup } from "../types";
import { INITIAL_COMBOS } from "../data/combos";
import { INITIAL_ACCOMMODATIONS } from "../data/accommodations";
import { DEFAULT_LIMOUSINE_CONFIG, DEFAULT_SHARED_CAR_CONFIG, INITIAL_COUPONS, INITIAL_LOCATIONS } from "../data/config";
import { INITIAL_DESTINATIONS } from "../data/destinations";
import { INITIAL_ARTICLES } from "../data/articles";
import { INITIAL_DRIVERS } from "../data/drivers";
import { INITIAL_ZALO_GROUPS } from "../data/zaloGroups";
import { getLocalList, getDeviceId } from "../lib/firebaseUtils";

export function useFirebaseSync() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [allBookings, setAllBookings] = useState<Booking[]>([]);
  const [blockedSeats, setBlockedSeats] = useState<BlockedSeat[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [reportedBookingIds, setReportedBookingIds] = useState<string[]>([]);
  
  // Use data from local data defaults or sync config if needed
  // For simplicity, sticking to initial data arrays for global configs, unless updated by admin
  const [combos, setCombos] = useState<TourCombo[]>(INITIAL_COMBOS);
  const [accommodations, setAccommodations] = useState<Accommodation[]>(INITIAL_ACCOMMODATIONS);
  const [limousineConfig, setLimousineConfig] = useState<LimousineConfig>(DEFAULT_LIMOUSINE_CONFIG);
  const [sharedCarConfig, setSharedCarConfig] = useState<SharedCarConfig>(DEFAULT_SHARED_CAR_CONFIG);
  const [coupons, setCoupons] = useState<Coupon[]>(INITIAL_COUPONS);
  const [locations, setLocations] = useState<LocationPoint[]>(INITIAL_LOCATIONS);
  const [destinations, setDestinations] = useState<Destination[]>(INITIAL_DESTINATIONS);
  const [articles, setArticles] = useState<GuideArticle[]>(INITIAL_ARTICLES);
  const [drivers, setDrivers] = useState<Driver[]>(() => getLocalList<Driver>("drivers", INITIAL_DRIVERS));
  const [zaloGroups, setZaloGroups] = useState<ZaloGroup[]>(() => getLocalList<ZaloGroup>("zalo_groups", INITIAL_ZALO_GROUPS));

  useEffect(() => {
    let unsubscribeProfile = () => {};
    const unsubAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      unsubscribeProfile();
      if (!firebaseUser) {
        setCurrentUser(null);
        setAuthReady(true);
        return;
      }
      try {
        const token = await firebaseUser.getIdTokenResult();
        const isAdmin = hasOperatorAccess(token);
        // Idempotent: a new UID gets 10 welcome points once; old members keep their balance.
        try { await ensureMemberProfile(firebaseUser, isAdmin); } catch (err) { console.warn("Member profile sync unavailable", err); }
        unsubscribeProfile = onSnapshot(doc(db, "users", firebaseUser.uid), snap => {
          if (snap.exists()) {
            const profile = snap.data() as User;
            // The UI role must not trust a self-editable Firestore role field.
            setCurrentUser({...profile, id: firebaseUser.uid, role: isAdmin ? 'operator' : 'customer'});
          } else {
            setCurrentUser({
              id: firebaseUser.uid,
              email: firebaseUser.email || '',
              name: firebaseUser.displayName || 'Thành viên',
              phone: firebaseUser.phoneNumber || '',
              points: 0,
              role: isAdmin ? 'operator' : 'customer'
            });
          }
          setAuthReady(true);
        }, error => {
          console.warn('Could not load profile from Firestore (Quota or offline fallback):', error);
          const localUsers = getLocalList<User>("users", []);
          const foundLocal = localUsers.find(u => u.id === firebaseUser.uid);
          if (foundLocal) {
            setCurrentUser({ ...foundLocal, role: isAdmin ? 'operator' : 'customer' });
          } else {
            setCurrentUser({
              id: firebaseUser.uid,
              email: firebaseUser.email || '',
              name: firebaseUser.displayName || 'Thành viên',
              phone: firebaseUser.phoneNumber || '',
              points: 0,
              role: isAdmin ? 'operator' : 'customer'
            });
          }
          setAuthReady(true);
        });
      } catch (error) {
        console.warn('Auth claim lookup failed:', error);
        const localUsers = getLocalList<User>("users", []);
        const foundLocal = localUsers.find(u => u.id === firebaseUser.uid);
        if (foundLocal) {
          setCurrentUser(foundLocal);
        } else {
          setCurrentUser({
            id: firebaseUser.uid,
            email: firebaseUser.email || '',
            name: firebaseUser.displayName || 'Thành viên',
            phone: firebaseUser.phoneNumber || '',
            points: 0,
            role: 'customer'
          });
        }
        setAuthReady(true);
      }
    });
    return () => {unsubAuth();unsubscribeProfile()};
  }, []);

  useEffect(() => {
    // Only fetch real-time public/protected data once auth is ready (even for unauthenticated users if your rules allow)
    // Bookings (customer sees theirs, admin sees all)
    let unsubBookings = () => {};
    let unsubBlocked = () => {};
    let unsubConfigs = () => {};
    let unsubNotifications = () => {};
    let unsubReports = () => {};
    let unsubCombosCol = () => {};
    let unsubAccCol = () => {};
    let unsubArticlesCol = () => {};
    let unsubCouponsCol = () => {};
    let unsubDestinationsCol = () => {};
    let unsubZaloGroups = () => {};

    if (authReady) {
      // Never subscribe to all passengers' bookings from a public browser.
      // Guest bookings are stored locally only after a confirmed Firestore write.
      if (currentUser?.role === 'operator') {
        unsubBookings = onSnapshot(collection(db, 'bookings'), snap => {
          const records = snap.docs.map(d => d.data() as Booking);
          setAllBookings(records);
          setBookings(records);
        }, err => handleFirestoreError(err, OperationType.LIST, 'bookings'));
      } else if (auth.currentUser && currentUser?.id) {
        unsubBookings = onSnapshot(query(collection(db, 'bookings'), where('userId','==',currentUser.id)), snap => {
          const remote = snap.docs.map(d => d.data() as Booking);
          const ownLocal = getLocalList<Booking>('bookings', []).filter(b=>b.userId===currentUser.id);
          const merged = new Map<string,Booking>(ownLocal.map(b=>[b.id,b]));
          remote.forEach(b=>merged.set(b.id,{...b,paymentReported:b.paymentReported || merged.get(b.id)?.paymentReported}));
          setBookings([...merged.values()]);
          setAllBookings([]);
        }, err => handleFirestoreError(err, OperationType.LIST, 'bookings'));
      } else {
        setAllBookings([]);
        setBookings(getLocalList<Booking>('bookings', []));
      }

      unsubCombosCol = onSnapshot(collection(db, "tour_combos"), (snap) => {
        setCombos(snap.docs.map(d => d.data() as TourCombo));
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, "tour_combos");
        setCombos(getLocalList<TourCombo>("combos", INITIAL_COMBOS));
      });

      unsubAccCol = onSnapshot(collection(db, "accommodations"), (snap) => {
        setAccommodations(snap.docs.map(d => d.data() as Accommodation));
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, "accommodations");
        setAccommodations(getLocalList<Accommodation>("accommodations", INITIAL_ACCOMMODATIONS));
      });

      unsubArticlesCol = onSnapshot(collection(db, "guide_articles"), (snap) => {
        setArticles(snap.docs.map(d => d.data() as GuideArticle));
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, "guide_articles");
        setArticles(getLocalList<GuideArticle>("articles", INITIAL_ARTICLES));
      });

      unsubCouponsCol = onSnapshot(collection(db, "coupons"), (snap) => {
        setCoupons(snap.docs.map(d => d.data() as Coupon));
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, "coupons");
        setCoupons(getLocalList<Coupon>("coupons", INITIAL_COUPONS));
      });

      unsubDestinationsCol = onSnapshot(collection(db, "destinations"), (snap) => {
        setDestinations(snap.docs.map(d => d.data() as Destination));
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, "destinations");
        setDestinations(getLocalList<Destination>("destinations", INITIAL_DESTINATIONS));
      });
      
      if (currentUser?.role === 'operator' && auth.currentUser) {
         const unsubUsers = onSnapshot(collection(db, "users"), (snap) => {
           setUsers(snap.docs.map(d => d.data() as User));
         }, (error) => {
           handleFirestoreError(error, OperationType.LIST, "users");
           setUsers(getLocalList<User>("users", []));
         });
         
         const originalUnsubBookings = unsubBookings;
         unsubBookings = () => { originalUnsubBookings(); unsubUsers(); };
      }

      // Blocked seats - public for reading to see availability
      unsubBlocked = onSnapshot(collection(db, "blocked_seats"), (snap) => {
         setBlockedSeats(snap.docs.map(d => d.data() as BlockedSeat));
      }, (error) => {
         handleFirestoreError(error, OperationType.LIST, "blocked_seats");
         setBlockedSeats(getLocalList<BlockedSeat>("blocked_seats", []));
      });

      // Configurations - public read from configs collection for global static params
      unsubConfigs = onSnapshot(collection(db, "configs"), (snap) => {
         if (!snap.empty) {
           snap.docs.forEach(docSnap => {
             const data = docSnap.data();
             if (data.limousineConfig) setLimousineConfig({ ...DEFAULT_LIMOUSINE_CONFIG, ...data.limousineConfig });
             if (data.sharedCarConfig) setSharedCarConfig({ ...DEFAULT_SHARED_CAR_CONFIG, ...data.sharedCarConfig });
             if (data.locations) setLocations(data.locations);
             if (data.drivers && Array.isArray(data.drivers)) setDrivers(data.drivers);
           });
         }

      }, (error) => handleFirestoreError(error, OperationType.LIST, "configs"));

      // Legacy notifications contain customer details; operator-only live feed.
      if (currentUser?.role === 'operator') {
        unsubNotifications = onSnapshot(collection(db, 'notifications'), snap => {
          setNotifications(snap.docs.map(d => d.data() as AppNotification).sort((a,b)=>
            new Date(b.timestamp).getTime()-new Date(a.timestamp).getTime()));
        }, err => handleFirestoreError(err, OperationType.LIST, 'notifications'));
      } else {
        setNotifications([]);
      }

      // Reports are independent, append-only signals from guests, not proof of payment.
      if(currentUser?.role==='operator') {
        unsubReports=onSnapshot(collection(db,'payment_reports'),snap=>{
          setReportedBookingIds([...new Set(snap.docs.map(d=>String(d.data().bookingId||'')).filter(Boolean))]);
        },err=>handleFirestoreError(err,OperationType.LIST,'payment_reports'));
      } else setReportedBookingIds([]);

      // Zalo Groups - public read for community
      unsubZaloGroups = onSnapshot(collection(db, "zalo_groups"), (snap) => {
        const list = snap.docs.map(d => d.data() as ZaloGroup);
        setZaloGroups(list.sort((a, b) => (a.order || 0) - (b.order || 0)));
      }, (error) => {
        console.warn("Could not read zalo_groups from Firestore, using local defaults:", error);
        setZaloGroups(getLocalList<ZaloGroup>("zalo_groups", INITIAL_ZALO_GROUPS));
      });
    }

    return () => {
      unsubBookings();
      unsubBlocked();
      unsubConfigs();
      unsubNotifications();
      unsubReports();
      unsubCombosCol();
      unsubAccCol();
      unsubArticlesCol();
      unsubCouponsCol();
      unsubDestinationsCol();
      unsubZaloGroups();
    };
  }, [authReady, currentUser?.role, currentUser?.id]);

  useEffect(() => {
    const handleUpdate = () => {
      if (!auth.currentUser) {
        setBookings(getLocalList<Booking>('bookings',[]));
        // Read from localStorage fallbacks
        
        const localBlocked = getLocalList<BlockedSeat>("blocked_seats", []);
        setBlockedSeats(localBlocked);
        
        const localUsers = getLocalList<User>("users", []);
        setUsers(localUsers);

        const localDrivers = getLocalList<Driver>("drivers", INITIAL_DRIVERS);
        setDrivers(localDrivers);

        try {
          const configsStr = localStorage.getItem("xemc_configs");
          if (configsStr) {
            const parsed = JSON.parse(configsStr);
            if (parsed.limousineConfig) setLimousineConfig(parsed.limousineConfig);
            if (parsed.sharedCarConfig) setSharedCarConfig(parsed.sharedCarConfig);
            if (parsed.combos) setCombos(parsed.combos);
            if (parsed.accommodations) setAccommodations(parsed.accommodations);
            if (parsed.coupons) setCoupons(parsed.coupons);
            if (parsed.locations) setLocations(parsed.locations);
            if (parsed.destinations) setDestinations(parsed.destinations);
            if (parsed.articles) setArticles(parsed.articles);
            if (parsed.drivers) setDrivers(parsed.drivers);
          }
        } catch (e) {
          // ignore
        }
      }
    };

    window.addEventListener("xedimocchau_db_update", handleUpdate);
    // Initial read
    handleUpdate();

    return () => {
      window.removeEventListener("xedimocchau_db_update", handleUpdate);
    };
  }, [authReady, currentUser]);

  return {
    currentUser,
    setCurrentUser,
    authReady,
    bookings,
    setBookings,
    allBookings,
    blockedSeats,
    setBlockedSeats,
    users,
    setUsers,
    notifications,
    setNotifications,
    reportedBookingIds,
    combos,
    setCombos,
    accommodations,
    setAccommodations,
    limousineConfig,
    setLimousineConfig,
    sharedCarConfig,
    setSharedCarConfig,
    coupons,
    setCoupons,
    locations,
    setLocations,
    destinations,
    setDestinations,
    articles,
    setArticles,
    drivers,
    setDrivers,
    zaloGroups,
    setZaloGroups
  };
}
