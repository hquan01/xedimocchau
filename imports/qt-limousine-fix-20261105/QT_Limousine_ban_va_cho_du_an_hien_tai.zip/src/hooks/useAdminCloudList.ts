import {useCallback, useEffect, useRef, useState} from 'react';
import type {Dispatch, SetStateAction} from 'react';
import {doc, onSnapshot, setDoc, serverTimestamp} from 'firebase/firestore';
import {db, auth} from '../firebase';
import {hasOperatorAccess} from '../lib/adminAccess';

/**
 * Cloud-backed admin list. A Firestore document is authoritative once it exists.
 * Empty [] is a valid saved state: NEVER reseed sample data after deletion.
 * Old device-only lists are migrated only after a deliberate edit by the operator.
 * Saves are serialized, and errors are visible instead of silently local-only.
 * Do not use for sensitive payments, roles, or wallet transactions.
 */
export function useAdminCloudList<T>(key:string, legacyLocalKey:string):[
  T[],Dispatch<SetStateAction<T[]>>,{saving:boolean;error:string;loaded:boolean}
]{
  const readLegacy=():T[]=>{
    try {const value=JSON.parse(localStorage.getItem(legacyLocalKey)||'null');return Array.isArray(value)?value:[]}
    catch{return []}
  };
  const [items,setItems]=useState<T[]>(readLegacy);
  const [saving,setSaving]=useState(false);
  const [error,setError]=useState('');
  const [loaded,setLoaded]=useState(false);
  const last=useRef<T[]>(items);
  const confirmed=useRef<T[]>(items);
  const queue=useRef<Promise<void>>(Promise.resolve());
  const pending=useRef(0);
  const mounted=useRef(true);
  const target=doc(db,'admin_collections',key);

  useEffect(()=>{
    mounted.current=true;
    return ()=>{mounted.current=false};
  },[]);

  useEffect(()=>onSnapshot(target,snapshot=>{
    setLoaded(true);
    if(!snapshot.exists()) return; // Keep legacy local rows until explicit migration.
    const remote=snapshot.data().items;
    if(!Array.isArray(remote)) {setError('Dữ liệu quản lý trên máy chủ không hợp lệ.');return}
    confirmed.current=remote as T[];
    if(pending.current===0){last.current=remote as T[];setItems(remote as T[])}
  },err=>{
    setLoaded(true);
    setError('Không đồng bộ được dữ liệu Quản lý: '+(err?.message||'Lỗi không xác định'));
  }),[key]);

  const update=useCallback<Dispatch<SetStateAction<T[]>>>((action)=>{
    const next=typeof action==='function' ? (action as (value:T[])=>T[])(last.current) : action;
    last.current=next;
    setItems(next); // optimistic UI; rollback if write fails
    setSaving(true);
    setError('');
    pending.current++;
    queue.current=queue.current.catch(()=>{}).then(async()=>{
      const user=auth.currentUser;
      if(!user)throw new Error('Phiên đăng nhập hết hạn. Vui lòng đăng nhập Admin lại.');
      const token=await user.getIdTokenResult(true);
      if(!hasOperatorAccess(token))throw new Error('Không có quyền quản trị. Kiểm tra quyền Firebase của tài khoản này.');
      await setDoc(doc(db,'admin_collections',key),{
        items:next, updatedAt:serverTimestamp(), updatedBy:user.uid
      });
      confirmed.current=next;
      try{localStorage.setItem(legacyLocalKey,JSON.stringify(next))}catch{}
    }).catch(err=>{
      console.error('Admin cloud write failed:',key,err);
      if(mounted.current){
        setError('Lưu thất bại: '+(err?.message||'Không được Firebase cho phép.'));
        last.current=confirmed.current;
        setItems(confirmed.current);
      }
    }).finally(()=>{
      pending.current=Math.max(0,pending.current-1);
      if(mounted.current)setSaving(pending.current>0);
    });
  },[key,legacyLocalKey]);
  return [items,update,{saving,error,loaded}];
}
