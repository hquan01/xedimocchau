import React, { useState, useEffect } from "react";
import { BlockedSeat, Booking, Seat, LimousineTrip, TourCombo, LimousineConfig, SharedCarConfig, Coupon, LocationPoint, Accommodation, Destination, GuideArticle, User as UserType, AppNotification, Driver, ZaloGroup } from "../types";
import { Check, X, Shield, Calendar, Clock, ArrowRight, User, Phone, Tag, Trash2, ListFilter, Search, Award, Lock, Unlock, Compass, ShieldCheck, Newspaper, MapPin, Star, Edit3, DollarSign, FileText, Banknote, Calculator, CalendarDays, ArrowUpDown, Layers, Bus, TrendingUp, Car, PhoneCall, UserCheck, MessageSquare } from "lucide-react";
import { motion } from "motion/react";
import { getOfficialSchedulesForRoute } from "./LimousineBooking";
import { getSharedCarSchedules } from "./SharedCarBooking";
import { INITIAL_DRIVERS } from "../data/drivers";
import ComboManagement from "./operator/ComboManagement";
import PricingManagement from "./operator/PricingManagement";
import CouponManagement from "./operator/CouponManagement";
import LocationManagement from "./operator/LocationManagement";
import AccommodationComboManagement from "./operator/AccommodationComboManagement";
import DestinationManagement from "./operator/DestinationManagement";
import ArticleManagement from "./operator/ArticleManagement";
import ScheduleManagement from "./operator/ScheduleManagement";
import ReviewManagement from "./operator/ReviewManagement";
import DriverManagement from "./operator/DriverManagement";
import ZaloCommunityManagement from "./operator/ZaloCommunityManagement";
import AdminSidebar from "./operator/AdminSidebar";
import MobileAdminDrawer from "./operator/MobileAdminDrawer";
import AdminTopBar from "./operator/AdminTopBar";
import RestaurantManagement from "./operator/RestaurantManagement";
import FlowerSeasonManagement from "./operator/FlowerSeasonManagement";
import AIAssistantManagement from "./operator/AIAssistantManagement";
import LiveWeatherManagement from "./operator/LiveWeatherManagement";
import PartnerManagement from "./operator/PartnerManagement";
import CommissionDebtManagement from "./operator/CommissionDebtManagement";
import GrowthAnalytics from "./operator/GrowthAnalytics";
import SecurityConfigManagement from "./operator/SecurityConfigManagement";
import TaxiFleetManagement from "./operator/TaxiFleetManagement";
import MotorbikeManagement from "./operator/MotorbikeManagement";
import ServiceInquiryManagement from "./operator/ServiceInquiryManagement";
import SiteContentStudio from "./operator/SiteContentStudio";

// Preset driver fleet for fast selection and autocomplete
export const DEFAULT_DRIVERS = INITIAL_DRIVERS;

// Helper functions for Date Formatting (ngày/tháng/năm: DD/MM/YYYY) and ISO conversion for accurate sorting
export const normalizeToISODate = (dateStr?: string): string => {
  if (!dateStr) return "9999-99-99";
  const trimmed = String(dateStr).trim();
  // YYYY-MM-DD or YYYY-M-D
  if (/^\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(trimmed)) {
    const parts = trimmed.split("T")[0].split(/[-/]/);
    const y = parts[0];
    const m = parts[1].padStart(2, "0");
    const d = parts[2].padStart(2, "0");
    return `${y}-${m}-${d}`;
  }
  // DD/MM/YYYY or D/M/YYYY
  if (/^\d{1,2}[-/]\d{1,2}[-/]\d{4}/.test(trimmed)) {
    const parts = trimmed.split(/[-/]/);
    const d = parts[0].padStart(2, "0");
    const m = parts[1].padStart(2, "0");
    const y = parts[2];
    return `${y}-${m}-${d}`;
  }
  return trimmed;
};

export const formatDisplayDate = (dateStr?: string): string => {
  if (!dateStr) return "-";
  const iso = normalizeToISODate(dateStr);
  if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) {
    const [y, m, d] = iso.split("-");
    return `${d}/${m}/${y}`;
  }
  return dateStr;
};

export const getDayOfWeekVN = (dateStr?: string): string => {
  if (!dateStr) return "";
  const iso = normalizeToISODate(dateStr);
  const d = new Date(iso + "T00:00:00");
  if (isNaN(d.getTime())) return "";
  const dayNames = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"];
  return dayNames[d.getDay()];
};

export interface TripGroupData {
  tripKey: string;
  departureTime: string;
  routeSelection: string;
  serviceType: string;
  bookings: Booking[];
  totalSeats: number;
  allSeatNumbers: string[];
  totalRevenue: number;
  totalDeposit: number;
  totalRemaining: number;
  assignedDriverName?: string;
  assignedDriverPhone?: string;
  assignedVehiclePlate?: string;
}

export interface DateGroupData {
  dateISO: string;
  dateDisplay: string;
  dayOfWeek: string;
  bookingsCount: number;
  totalSeatsCount: number;
  totalRevenue: number;
  totalDeposit: number;
  totalRemaining: number;
  trips: TripGroupData[];
}

interface OperatorPanelProps {
  users: UserType[];
  bookings: Booking[];
  onUpdateBookingStatus: (bookingId: string, status: "pending" | "success" | "completed" | "cancelled") => void;
  onDeleteBooking: (bookingId: string) => void;
  onBulkDeleteBookings: (bookingIds: string[]) => void;
  blockedSeats: BlockedSeat[];
  onToggleBlockedSeat: (seatId: string, travelDate: string, tripId: string, customerPhone?: string) => void;
  onRemoveBlockedSeat: (seat: BlockedSeat) => void;
  combos: TourCombo[];
  onUpdateCombos: (updated: TourCombo[]) => void;
  limousineConfig: LimousineConfig;
  onUpdateLimousineConfig: (updated: LimousineConfig) => void;
  sharedCarConfig: SharedCarConfig;
  onUpdateSharedCarConfig: (updated: SharedCarConfig) => void;
  coupons: Coupon[];
  onUpdateCoupons: (updated: Coupon[]) => void;
  locations: LocationPoint[];
  onUpdateLocations: (updated: LocationPoint[]) => void;
  accommodations: Accommodation[];
  onUpdateAccommodations: (updated: Accommodation[]) => void;
  destinations: Destination[];
  onUpdateDestinations: (updated: Destination[]) => void;
  articles: GuideArticle[];
  onUpdateArticles: (updated: GuideArticle[]) => void;
  notifications: AppNotification[];
  onUpdateNotifications: (updated: AppNotification[]) => void;
  onSendNotification: (title: string, message: string) => void;
  drivers?: Driver[];
  onUpdateDrivers?: (updated: Driver[]) => void;
  zaloGroups?: ZaloGroup[];
  onUpdateZaloGroups?: (updated: ZaloGroup[]) => void;
}

const INITIAL_SEATS_TEMPLATE: Seat[] = [
  { id: "s1", number: "A1", type: "front", price: 300000, isBooked: false },
  { id: "s2", number: "A2", type: "front", price: 300000, isBooked: false },
  { id: "s3", number: "A3", type: "vip_massage", price: 330000, isBooked: false },
  { id: "s4", number: "A4", type: "vip_massage", price: 330000, isBooked: false },
  { id: "s5", number: "A5", type: "vip_massage", price: 330000, isBooked: false },
  { id: "s6", number: "A6", type: "vip_massage", price: 330000, isBooked: false },
  { id: "s7", number: "A7", type: "standard", price: 300000, isBooked: false },
  { id: "s8", number: "A8", type: "standard", price: 300000, isBooked: false },
  { id: "s9", number: "A9", type: "standard", price: 300000, isBooked: false },
];

const INITIAL_SEATS_SHARED: Seat[] = [
  { id: "s1", number: "A1", type: "front", price: 350000, isBooked: false },
  { id: "s2", number: "B1", type: "vip_massage", price: 350000, isBooked: false },
  { id: "s3", number: "B2", type: "vip_massage", price: 350000, isBooked: false },
  { id: "s4", number: "B3", type: "vip_massage", price: 350000, isBooked: false },
  { id: "s5", number: "C1", type: "standard", price: 350000, isBooked: false },
  { id: "s6", number: "C2", type: "standard", price: 350000, isBooked: false },
];

export default function OperatorPanel({
  users,
  bookings,
  onUpdateBookingStatus,
  onDeleteBooking,
  onBulkDeleteBookings,
  blockedSeats,
  onToggleBlockedSeat,
  onRemoveBlockedSeat,
  combos,
  onUpdateCombos,
  limousineConfig,
  onUpdateLimousineConfig,
  sharedCarConfig,
  onUpdateSharedCarConfig,
  coupons,
  onUpdateCoupons,
  locations,
  onUpdateLocations,
  accommodations,
  onUpdateAccommodations,
  destinations,
  onUpdateDestinations,
  articles,
  onUpdateArticles,
  drivers = INITIAL_DRIVERS,
  onUpdateDrivers = () => {},
  zaloGroups = [],
  onUpdateZaloGroups = () => {}
}: OperatorPanelProps) {
  // Navigation tabs & 16 Modules inside Operator 2.0
  const [activeModuleId, setActiveModuleId] = useState<string>("overview");
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [panelTab, setPanelTab] = useState<"bookings" | "seatLock" | "customers" | "overview" | "travelServices" | "pricing" | "coupons" | "locations" | "content" | "schedules" | "reviews" | "drivers" | "zaloCommunity">("overview");
  const [activeContentTab, setActiveContentTab] = useState<"destinations" | "articles">("destinations");
  const [userToDelete, setUserToDelete] = useState<any>(null);

  const handleSelectModule = (modId: string) => {
    setActiveModuleId(modId);
    if (modId === "limousine_bookings") setPanelTab("bookings");
    else if (modId === "limousine_seatlock") setPanelTab("seatLock");
    else if (modId === "limousine_customers") setPanelTab("customers");
    else if (modId === "overview") setPanelTab("overview");
    else if (modId === "limousine_schedules") setPanelTab("schedules");
    else if (modId === "limousine_pricing") setPanelTab("pricing");
    else if (modId === "limousine_drivers") setPanelTab("drivers");
    else if (modId === "limousine_locations") setPanelTab("locations");
    else if (modId === "limousine_coupons") setPanelTab("coupons");
    else if (modId === "accommodations_combos") setPanelTab("travelServices");
    else if (modId === "destinations") { setPanelTab("content"); setActiveContentTab("destinations"); }
    else if (modId === "articles_guide") { setPanelTab("content"); setActiveContentTab("articles"); }
    else if (modId === "customer_reviews") setPanelTab("reviews");
    else if (modId === "community_zalo") setPanelTab("zaloCommunity");
  };

  // Selection states for bulk actions
  const [selectedBookingIds, setSelectedBookingIds] = useState<string[]>([]);
  // Dual-state verification for deletions to avoid window.confirm
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [bulkDeleteConfirm, setBulkDeleteConfirm] = useState(false);

  // Booking filtering states
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "success" | "completed" | "cancelled">("all");
  const [typeFilter, setTypeFilter] = useState<"all" | "limousine" | "shared_car" | "private_charter" | "combo">("all");
  const [dateFilter, setDateFilter] = useState("");
  const [viewMode, setViewMode] = useState<"grouped" | "table">("grouped");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");

  // Seat Locking custom states
  const [lockService, setLockService] = useState<"limousine" | "shared_car">("limousine");
  const [lockFrom, setLockFrom] = useState("Hà Nội");
  const [lockTo, setLockTo] = useState("Mộc Châu");
  const [lockDate, setLockDate] = useState(() => new Date().toISOString().substring(0, 10));
  
  const activeDepartureHours = lockService === "limousine"
    ? getOfficialSchedulesForRoute(lockFrom, lockTo, lockDate, limousineConfig)
    : getSharedCarSchedules();
  const [lockTime, setLockTime] = useState("06:00");
  const [lockPhone, setLockPhone] = useState("");

  // Seat editing/details state
  const [selectedSeatForEdit, setSelectedSeatForEdit] = useState<{
    seat: Seat;
    isVip: boolean;
  } | null>(null);

  const [seatPassengerName, setSeatPassengerName] = useState("");
  const [seatPassengerPhone, setSeatPassengerPhone] = useState("");
  const [seatPickupPoint, setSeatPickupPoint] = useState("");
  const [seatDropoffPoint, setSeatDropoffPoint] = useState("");
  const [seatNotes, setSeatNotes] = useState("");
  const [isUpdatingSeat, setIsUpdatingSeat] = useState(false);

  // Deposit, Driver & Operator Notes Editing States
  const [editingDepositBooking, setEditingDepositBooking] = useState<Booking | null>(null);
  const [editDepositAmount, setEditDepositAmount] = useState<number>(0);
  const [editOperatorNotes, setEditOperatorNotes] = useState<string>("");
  const [editDriverName, setEditDriverName] = useState<string>("");
  const [editDriverPhone, setEditDriverPhone] = useState<string>("");
  const [editVehiclePlate, setEditVehiclePlate] = useState<string>("");
  const [applyDriverToEntireTrip, setApplyDriverToEntireTrip] = useState<boolean>(false);
  const [isSavingDepositNotes, setIsSavingDepositNotes] = useState(false);

  // Trip-level batch driver assignment
  const [assigningTripGroup, setAssigningTripGroup] = useState<TripGroupData | null>(null);
  const [tripDriverName, setTripDriverName] = useState<string>("");
  const [tripDriverPhone, setTripDriverPhone] = useState<string>("");
  const [tripVehiclePlate, setTripVehiclePlate] = useState<string>("");
  const [isSavingTripDriver, setIsSavingTripDriver] = useState<boolean>(false);

  const handleOpenDepositModal = (bk: Booking) => {
    setEditingDepositBooking(bk);
    setEditDepositAmount(bk.depositAmount || 0);
    setEditOperatorNotes(bk.operatorNotes || "");
    setEditDriverName(bk.driverName || "");
    setEditDriverPhone(bk.driverPhone || "");
    setEditVehiclePlate(bk.vehiclePlate || "");
    setApplyDriverToEntireTrip(false);
  };

  const handleSaveDepositAndNotes = async () => {
    if (!editingDepositBooking) return;
    setIsSavingDepositNotes(true);
    try {
      const updates: Partial<Booking> = {
        depositAmount: Math.max(0, Number(editDepositAmount) || 0),
        operatorNotes: editOperatorNotes.trim(),
        driverName: editDriverName.trim(),
        driverPhone: editDriverPhone.trim(),
        vehiclePlate: editVehiclePlate.trim(),
      };

      const { db } = await import("../firebase");
      const { doc, setDoc } = await import("firebase/firestore");
      const { getLocalList, setLocalList } = await import("../lib/firebaseUtils");
      const current = getLocalList<Booking>("bookings", []);

      if (applyDriverToEntireTrip) {
        // Find all bookings with same travelDate, departureTime, routeSelection
        const sameTripBookings = bookings.filter(b => 
          b.travelDate === editingDepositBooking.travelDate && 
          b.departureTime === editingDepositBooking.departureTime &&
          (b.routeSelection === editingDepositBooking.routeSelection || b.type === editingDepositBooking.type)
        );

        for (const b of sameTripBookings) {
          const itemUpdates: Partial<Booking> = {
            driverName: editDriverName.trim(),
            driverPhone: editDriverPhone.trim(),
            vehiclePlate: editVehiclePlate.trim(),
            ...(b.id === editingDepositBooking.id ? {
              depositAmount: Math.max(0, Number(editDepositAmount) || 0),
              operatorNotes: editOperatorNotes.trim(),
            } : {})
          };
          await setDoc(doc(db, "bookings", b.id), itemUpdates, { merge: true });
          const idx = current.findIndex(item => item.id === b.id);
          if (idx > -1) {
            current[idx] = { ...current[idx], ...itemUpdates };
          }
        }
      } else {
        await setDoc(doc(db, "bookings", editingDepositBooking.id), updates, { merge: true });
        const idx = current.findIndex(b => b.id === editingDepositBooking.id);
        if (idx > -1) {
          current[idx] = { ...current[idx], ...updates };
        }
      }

      setLocalList("bookings", current);
      setEditingDepositBooking(null);
    } catch (err) {
      console.error("Error saving deposit, driver and notes:", err);
      alert("Đã xảy ra lỗi khi lưu thông tin cọc, lái xe & ghi chú!");
    } finally {
      setIsSavingDepositNotes(false);
    }
  };

  const handleOpenAssignTripDriver = (trip: TripGroupData) => {
    setAssigningTripGroup(trip);
    setTripDriverName(trip.assignedDriverName || "");
    setTripDriverPhone(trip.assignedDriverPhone || "");
    setTripVehiclePlate(trip.assignedVehiclePlate || "");
  };

  const handleSaveTripDriver = async () => {
    if (!assigningTripGroup || assigningTripGroup.bookings.length === 0) return;
    setIsSavingTripDriver(true);
    try {
      const updates: Partial<Booking> = {
        driverName: tripDriverName.trim(),
        driverPhone: tripDriverPhone.trim(),
        vehiclePlate: tripVehiclePlate.trim(),
      };

      const { db } = await import("../firebase");
      const { doc, setDoc } = await import("firebase/firestore");
      const { getLocalList, setLocalList } = await import("../lib/firebaseUtils");
      const current = getLocalList<Booking>("bookings", []);

      for (const b of assigningTripGroup.bookings) {
        await setDoc(doc(db, "bookings", b.id), updates, { merge: true });
        const idx = current.findIndex(item => item.id === b.id);
        if (idx > -1) {
          current[idx] = { ...current[idx], ...updates };
        }
      }
      setLocalList("bookings", current);
      setAssigningTripGroup(null);
    } catch (err) {
      console.error("Error saving trip driver:", err);
      alert("Đã xảy ra lỗi khi gán lái xe cho chuyến!");
    } finally {
      setIsSavingTripDriver(false);
    }
  };

  // Dynamic feedback update on hour change mapping safety
  useEffect(() => {
    const hours = lockService === "limousine"
      ? getOfficialSchedulesForRoute(lockFrom, lockTo, lockDate, limousineConfig)
      : getSharedCarSchedules();
    if (!hours.includes(lockTime)) {
      setLockTime(hours[0] || "06:00");
    }
  }, [lockFrom, lockTo, lockService, lockDate, limousineConfig]);

  // Statistics calculation helpers
  const today = new Date().toISOString().substring(0, 10);
  
  const todayBookings = bookings.filter(b => b.travelDate === today && b.status !== "cancelled");
  const confirmedTodayCount = todayBookings.length;
  const todayLimousine = todayBookings.filter(b => b.type === "limousine" || b.type === "shared_car");
  const todayCombos = todayBookings.filter(b => b.type === "combo");

  // Group limousine by trip for reminder
  const tripGroups: Record<string, { count: number, time: string, route: string }> = {};
  todayLimousine.forEach(b => {
    const key = `${b.routeSelection}_${b.departureTime}`;
    if (!tripGroups[key]) {
      tripGroups[key] = { count: 0, time: b.departureTime || "", route: b.routeSelection || "" };
    }
    tripGroups[key].count += (b.seatNumbers?.length || b.seatCount || 1);
  });

  const totalRevenue = bookings
    .filter((b) => b.status === "success" || b.status === "completed")
    .reduce((val, b) => val + b.totalPrice, 0);

  const pendingBookingsCount = bookings.filter((b) => b.status === "pending").length;
  const activeBookedSeatsCount = bookings
    .filter((b) => (b.status === "success" || b.status === "completed") && b.seatNumbers)
    .reduce((sum, b) => sum + (b.seatNumbers?.length || 0), 0);

  // Directional Booking count metrics (Professional Bento statistics)
  const hnMcCount = bookings.filter(b => b.type === "limousine" && (b.routeSelection || "").includes("Hà Nội") && (b.status === "success" || b.status === "completed")).length;
  const mcHnCount = bookings.filter(b => b.type === "limousine" && (b.routeSelection || "").includes("Mộc Châu") && (b.status === "success" || b.status === "completed")).length;
  const comboCount = bookings.filter(b => b.type === "combo" && (b.status === "success" || b.status === "completed")).length;

  // Filtered booking lists
  const filteredBookings = bookings.filter((bk) => {
    const sTerm = searchTerm.toLowerCase();
    const matchesSearch =
      (bk.passengerName || "").toLowerCase().includes(sTerm) ||
      (bk.passengerPhone || "").includes(sTerm) ||
      (bk.seatNumbers && bk.seatNumbers.join(", ").toLowerCase().includes(sTerm)) ||
      ((bk.id || "").toLowerCase().includes(sTerm)) ||
      ((bk.driverName || "").toLowerCase().includes(sTerm)) ||
      ((bk.driverPhone || "").includes(sTerm)) ||
      ((bk.vehiclePlate || "").toLowerCase().includes(sTerm)) ||
      ((bk.operatorNotes || "").toLowerCase().includes(sTerm));

    const matchesStatus = statusFilter === "all" || bk.status === statusFilter;
    const matchesType = typeFilter === "all" || bk.type === typeFilter;
    const matchesDate = !dateFilter || normalizeToISODate(bk.travelDate) === dateFilter;

    return matchesSearch && matchesStatus && matchesType && matchesDate;
  });

  // 1. Sort bookings strictly by Travel Date (Ngày khởi hành) then by Trip (Giờ chạy + Tuyến đường)
  const sortedBookings = [...filteredBookings].sort((a, b) => {
    const dateA = normalizeToISODate(a.travelDate);
    const dateB = normalizeToISODate(b.travelDate);
    
    if (dateA !== dateB) {
      return sortOrder === "asc" ? dateA.localeCompare(dateB) : dateB.localeCompare(dateA);
    }
    
    // Same date -> Sort by departure time (06:00, 07:00, 13:00, 14:00, 16:00...)
    const timeA = (a.departureTime || "00:00").padStart(5, "0");
    const timeB = (b.departureTime || "00:00").padStart(5, "0");
    if (timeA !== timeB) {
      return timeA.localeCompare(timeB);
    }
    
    // Same time -> Sort by route
    const routeA = a.routeSelection || "";
    const routeB = b.routeSelection || "";
    if (routeA !== routeB) {
      return routeA.localeCompare(routeB);
    }

    return (b.id || "").localeCompare(a.id || "");
  });

  // 2. Group into DateGroups -> TripGroups for crystal-clear visual hierarchy
  const groupedByDateAndTrip: DateGroupData[] = [];

  sortedBookings.forEach((bk) => {
    const dateISO = normalizeToISODate(bk.travelDate);
    let dateGroup = groupedByDateAndTrip.find((g) => g.dateISO === dateISO);

    if (!dateGroup) {
      dateGroup = {
        dateISO,
        dateDisplay: formatDisplayDate(bk.travelDate),
        dayOfWeek: getDayOfWeekVN(bk.travelDate),
        bookingsCount: 0,
        totalSeatsCount: 0,
        totalRevenue: 0,
        totalDeposit: 0,
        totalRemaining: 0,
        trips: [],
      };
      groupedByDateAndTrip.push(dateGroup);
    }

    // Calculate Date Group aggregates
    const seatsInBooking = bk.seatNumbers?.length || bk.seatCount || 1;
    const deposit = bk.depositAmount || 0;
    const remaining = Math.max(0, bk.totalPrice - deposit);

    dateGroup.bookingsCount += 1;
    dateGroup.totalSeatsCount += seatsInBooking;
    dateGroup.totalRevenue += bk.totalPrice;
    dateGroup.totalDeposit += deposit;
    dateGroup.totalRemaining += remaining;

    // Find or create trip in dateGroup
    const tripTime = bk.departureTime || "Chưa định giờ";
    const tripRoute = bk.routeSelection || (bk.type === "combo" ? bk.accommodationName : "Theo yêu cầu") || "Mộc Châu ➔ Hà Nội";
    const tripKey = `${tripTime}___${tripRoute}___${bk.type}`;

    let tripGroup = dateGroup.trips.find((t) => t.tripKey === tripKey);
    if (!tripGroup) {
      tripGroup = {
        tripKey,
        departureTime: tripTime,
        routeSelection: tripRoute,
        serviceType: bk.type,
        bookings: [],
        totalSeats: 0,
        allSeatNumbers: [],
        totalRevenue: 0,
        totalDeposit: 0,
        totalRemaining: 0,
        assignedDriverName: bk.driverName,
        assignedDriverPhone: bk.driverPhone,
        assignedVehiclePlate: bk.vehiclePlate,
      };
      dateGroup.trips.push(tripGroup);
    }

    tripGroup.bookings.push(bk);
    tripGroup.totalSeats += seatsInBooking;
    if (bk.seatNumbers && bk.seatNumbers.length > 0) {
      tripGroup.allSeatNumbers.push(...bk.seatNumbers);
    }
    tripGroup.totalRevenue += bk.totalPrice;
    tripGroup.totalDeposit += deposit;
    tripGroup.totalRemaining += remaining;

    // If tripGroup didn't have driver assigned yet, take from booking if present
    if (!tripGroup.assignedDriverName && bk.driverName) {
      tripGroup.assignedDriverName = bk.driverName;
      tripGroup.assignedDriverPhone = bk.driverPhone;
      tripGroup.assignedVehiclePlate = bk.vehiclePlate;
    }
  });

  // Handle professional dispatch sheet export (UTF-8 Excel CSV Compatible)
  const handleExportCSV = () => {
    const activeBookings = sortedBookings.filter(b => b.status === "success" || b.status === "completed" || b.status === "pending");
    if (activeBookings.length === 0) {
      alert("Không có dữ liệu hành khách hoạt động trong bộ lọc hiện tại để xuất danh sách!");
      return;
    }
    
    let csvContent = "\uFEFF"; // UTF-8 BOM so Vietnamese displays perfectly in Excel!
    csvContent += "Mã Vé,Họ Tên Khách,Số Điện Thoại,Loại Hình,Hành Trình,Chi Tiết Ghế/Phòng,Ngày Khởi Hành,Giờ Chạy,Lái Xe Phụ Trách,SĐT Lái Xe,Biển Số Xe,Điểm Đón,Điểm Trả,Tổng Tiền (VNĐ),Đã Cọc (VNĐ),Còn Phải Thu (VNĐ),Ghi Chú Nhà Xe,Ghi Chú Khách,Trạng Thái\n";
    
    activeBookings.forEach(b => {
      const seatOrRooms = (b.type === "limousine" || b.type === "shared_car")
        ? (b.seatNumbers?.join("; ") || `${b.seatCount || 1} ghế`)
        : b.type === "private_charter"
        ? `Nguyên xe (${b.seatCount || "7"} chỗ)`
        : `${b.roomTypeName} (${b.roomQuantity} phòng)`;
      const route = (b.type === "limousine" || b.type === "shared_car") ? b.routeSelection : b.type === "private_charter" ? `${b.pickupPoint} - ${b.dropoffPoint}` : `${b.accommodationName}`;
      const serviceType = b.type === "limousine" ? "Xe Limousine VIP" : b.type === "shared_car" ? "Xe Ghép 7 Chỗ" : b.type === "private_charter" ? "Thuê Xe Riêng" : "Combo Du Lịch";
      
      const deposit = b.depositAmount || 0;
      const remaining = Math.max(0, b.totalPrice - deposit);
      const opNotes = (b.operatorNotes || "").replace(/"/g, '""');
      const custNotes = (b.notes || "").replace(/"/g, '""');
      const drName = (b.driverName || "").replace(/"/g, '""');
      const drPhone = (b.driverPhone || "").replace(/"/g, '""');
      const drPlate = (b.vehiclePlate || "").replace(/"/g, '""');

      csvContent += `"${(b.id || "").toUpperCase()}","${b.passengerName}","${b.passengerPhone}","${serviceType}","${route}","${seatOrRooms}","${formatDisplayDate(b.travelDate)}","${b.departureTime || '-'}","${drName}","${drPhone}","${drPlate}","${b.pickupPoint}","${b.dropoffPoint}","${b.totalPrice}","${deposit}","${remaining}","${opNotes}","${custNotes}","${b.status === 'success' ? 'Đã duyệt (OK)' : b.status === 'completed' ? 'Đã hoàn thành' : 'Chờ xử lý'}"\n`;
    });
    
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Bieu-Khoi-Hanh-LimousineMocChau_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle single status updates (Accept Payment / Cancel bookings)
  const handleUpdateStatus = (bookingId: string, nextStatus: 'pending' | 'success' | 'completed' | 'cancelled') => {
    onUpdateBookingStatus(bookingId, nextStatus);
  };

  // Handle booking deletion to free up storage
  const handleDeleteBooking = (bookingId: string) => {
    onDeleteBooking(bookingId);
    setDeleteConfirmId(null);
    setSelectedBookingIds(prev => prev.filter(id => id !== bookingId));
  };

  // Bulk deletion of multiple selected bookings
  const handleBulkDeleteBookings = () => {
    onBulkDeleteBookings(selectedBookingIds);
    setSelectedBookingIds([]);
    setBulkDeleteConfirm(false);
  };

  // Toggle seat blocking:
  const getBlockedItemForSeat = (seatId: string) => {
    const pathTripId = lockService === "limousine" 
      ? `trip_custom_${lockTime.replace(":", "_")}` 
      : `shared_car_trip_custom_${lockTime.replace(":", "_")}`;
    return blockedSeats.find(
      (b) => b.seatId === seatId && b.travelDate === lockDate && b.tripId === pathTripId
    );
  };

  const isSeatBlocked = (seatId: string) => {
    return !!getBlockedItemForSeat(seatId);
  };

  const getOnlineBookingForSeat = (seatNumber: string) => {
    return bookings.find(
      (b) =>
        b.type === lockService &&
        b.status !== "cancelled" &&
        b.travelDate === lockDate &&
        b.departureTime === lockTime &&
        b.seatNumbers?.includes(seatNumber)
    );
  };

  const handleSaveSeatEdit = async () => {
    if (!selectedSeatForEdit) return;
    const { seat } = selectedSeatForEdit;
    const onlineBooking = getOnlineBookingForSeat(seat.number);

    setIsUpdatingSeat(true);
    try {
      if (onlineBooking) {
        const { db } = await import("../firebase");
        const { doc, updateDoc } = await import("firebase/firestore");
        await updateDoc(doc(db, "bookings", onlineBooking.id), {
          passengerName: seatPassengerName,
          passengerPhone: seatPassengerPhone,
          pickupPoint: seatPickupPoint,
          dropoffPoint: seatDropoffPoint,
          notes: seatNotes,
        });

        const { getLocalList, setLocalList } = await import("../lib/firebaseUtils");
        const current = getLocalList<Booking>("bookings", []);
        const idx = current.findIndex(b => b.id === onlineBooking.id);
        if (idx > -1) {
          current[idx] = {
            ...current[idx],
            passengerName: seatPassengerName,
            passengerPhone: seatPassengerPhone,
            pickupPoint: seatPickupPoint,
            dropoffPoint: seatDropoffPoint,
            notes: seatNotes,
          };
          setLocalList("bookings", current);
        }
      } else {
        const pathTripId = lockService === "limousine" 
          ? `trip_custom_${lockTime.replace(":", "_")}` 
          : `shared_car_trip_custom_${lockTime.replace(":", "_")}`;

        const seatParams = {
          seatId: seat.id,
          travelDate: lockDate,
          tripId: pathTripId,
          customerPhone: seatPassengerPhone,
          customerName: seatPassengerName,
          pickupPoint: seatPickupPoint,
          dropoffPoint: seatDropoffPoint,
          note: seatNotes,
        };

        const { saveBlockedSeatToFirebase } = await import("../lib/firebaseUtils");
        await saveBlockedSeatToFirebase(seatParams);
      }
      setSelectedSeatForEdit(null);
    } catch (e) {
      console.error(e);
      alert("Đã xảy ra lỗi khi lưu thông tin ghế.");
    } finally {
      setIsUpdatingSeat(false);
    }
  };

  const handleUnlockSeatDirect = async () => {
    if (!selectedSeatForEdit) return;
    const { seat } = selectedSeatForEdit;
    
    setIsUpdatingSeat(true);
    try {
      const pathTripId = lockService === "limousine" 
        ? `trip_custom_${lockTime.replace(":", "_")}` 
        : `shared_car_trip_custom_${lockTime.replace(":", "_")}`;

      const { deleteBlockedSeatFromFirebase } = await import("../lib/firebaseUtils");
      await deleteBlockedSeatFromFirebase({
        seatId: seat.id,
        travelDate: lockDate,
        tripId: pathTripId,
      });

      setSelectedSeatForEdit(null);
    } catch (e) {
      console.error(e);
      alert("Đã xảy ra lỗi khi mở khóa ghế.");
    } finally {
      setIsUpdatingSeat(false);
    }
  };

  const handleEditBlockedSeatFromList = (bs: BlockedSeat) => {
    const template = lockService === "limousine" ? INITIAL_SEATS_TEMPLATE : INITIAL_SEATS_SHARED;
    const foundSeat = template.find(s => s.id === bs.seatId) || {
      id: bs.seatId,
      number: bs.seatId.toUpperCase().replace("S", "A"),
      type: "standard",
      price: 300000,
      isBooked: false
    };
    setSelectedSeatForEdit({
      seat: foundSeat,
      isVip: foundSeat.type.includes("vip")
    });
    setSeatPassengerName(bs.customerName || "");
    setSeatPassengerPhone(bs.customerPhone || "");
    setSeatPickupPoint(bs.pickupPoint || "");
    setSeatDropoffPoint(bs.dropoffPoint || "");
    setSeatNotes(bs.note || "");
  };

  const renderSeatMapButton = (seat: Seat, isVip: boolean) => {
    const onlineBooking = getOnlineBookingForSeat(seat.number);
    const blockedItem = getBlockedItemForSeat(seat.id);

    const handleSeatClick = () => {
      setSelectedSeatForEdit({ seat, isVip });
      if (onlineBooking) {
        setSeatPassengerName(onlineBooking.passengerName || "");
        setSeatPassengerPhone(onlineBooking.passengerPhone || "");
        setSeatPickupPoint(onlineBooking.pickupPoint || "");
        setSeatDropoffPoint(onlineBooking.dropoffPoint || "");
        setSeatNotes(onlineBooking.notes || "");
      } else if (blockedItem) {
        setSeatPassengerName(blockedItem.customerName || "");
        setSeatPassengerPhone(blockedItem.customerPhone || "");
        setSeatPickupPoint(blockedItem.pickupPoint || "");
        setSeatDropoffPoint(blockedItem.dropoffPoint || "");
        setSeatNotes(blockedItem.note || "");
      } else {
        setSeatPassengerName("");
        setSeatPassengerPhone(lockPhone.trim());
        setSeatPickupPoint("");
        setSeatDropoffPoint("");
        setSeatNotes("");
      }
    };

    if (onlineBooking) {
      return (
        <button
          key={seat.id}
          type="button"
          onClick={handleSeatClick}
          className={`px-1 rounded-xl border border-indigo-700 bg-indigo-600 hover:bg-indigo-750 hover:scale-[1.02] transition-all text-white font-sans text-center flex flex-col items-center justify-center gap-0.5 shrink-0 select-none shadow-md cursor-pointer ${
            isVip ? "h-24 py-4" : "h-20 py-3"
          }`}
          title={`Đã Đặt Online: ${onlineBooking.passengerName} (${onlineBooking.passengerPhone}). Click để xem/sửa chi tiết.`}
        >
          <User className="w-3.5 h-3.5 text-indigo-200" />
          <span className="text-[10px] font-black block leading-none">Ghế {seat.number} {isVip ? "(VIP)" : ""}</span>
          <span className="text-[9px] bg-indigo-800/80 px-1 py-0.5 rounded-md font-bold truncate max-w-full text-indigo-100 font-mono mt-0.5">
            📞 {onlineBooking.passengerPhone}
          </span>
          <span className="text-[8px] opacity-85 leading-none truncate max-w-full block font-semibold">Khách: {onlineBooking.passengerName}</span>
        </button>
      );
    }

    if (blockedItem) {
      return (
        <button
          key={seat.id}
          type="button"
          onClick={handleSeatClick}
          className={`px-1 rounded-xl border border-red-700 bg-red-600 hover:bg-red-750 hover:scale-[1.02] text-white font-sans text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 shrink-0 shadow-md ${
            isVip ? "h-24 py-4" : "h-20 py-3"
          }`}
          title={`Đã Khóa: Click để xem/sửa thông tin hoặc giải phóng.`}
        >
          <Lock className="w-3.5 h-3.5 text-red-200" />
          <span className="text-[10px] font-black block leading-none">Ghế {seat.number} {isVip ? "(VIP)" : ""}</span>
          {blockedItem.customerPhone ? (
            <span className="text-[9px] bg-red-800/80 px-1 py-0.5 rounded-md font-extrabold text-red-100 font-mono mt-0.5">
              📞 {blockedItem.customerPhone}
            </span>
          ) : (
            <span className="text-[9px] bg-red-800/80 px-1 py-0.5 rounded-md font-bold text-red-200 mt-0.5">
              ĐÃ KHÓA
            </span>
          )}
          {blockedItem.customerName ? (
            <span className="text-[8px] opacity-90 leading-none truncate max-w-full block font-bold text-red-100">
              Khách: {blockedItem.customerName}
            </span>
          ) : (
            <span className="text-[8px] opacity-80 leading-none block font-mono font-bold">Mở Khóa</span>
          )}
        </button>
      );
    }

    return (
      <button
        key={seat.id}
        type="button"
        onClick={handleSeatClick}
        className={`px-1 rounded-xl border font-sans text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 shrink-0 hover:scale-[1.02] ${
          isVip
            ? "border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-emerald-950 h-24 py-4"
            : "border-stone-200 bg-white hover:bg-stone-50 text-stone-800 h-20 py-3"
        }`}
        title={`Bấm để nhập thông tin & khóa ghế`}
      >
        <Unlock className={`w-3.5 h-3.5 ${isVip ? "text-emerald-600" : "text-stone-400"}`} />
        <span className="text-[10px] font-extrabold block leading-none">Ghế {seat.number} {isVip ? "(VIP)" : ""}</span>
        <span className="text-[9px] text-stone-500 font-mono font-bold">{seat.price / 1000}k VNĐ</span>
        <span className="text-[8px] text-stone-400 leading-none font-bold">Bấm Khóa</span>
      </button>
    );
  };

  return (
    <div className="flex bg-stone-100 min-h-screen text-stone-900 font-sans text-left" id="operator_dashboard_container">
      {/* 1. Desktop Sidebar */}
      <div className="hidden md:flex">
        <AdminSidebar
          activeModuleId={activeModuleId}
          onSelectModule={handleSelectModule}
          pendingBookingsCount={pendingBookingsCount}
        />
      </div>

      {/* 2. Mobile Navigation Drawer (< md) */}
      <MobileAdminDrawer
        isOpen={isMobileDrawerOpen}
        onClose={() => setIsMobileDrawerOpen(false)}
        activeModuleId={activeModuleId}
        onSelectModule={handleSelectModule}
        pendingBookingsCount={pendingBookingsCount}
      />

      {/* 3. Main Workspace Canvas */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto">
        <AdminTopBar
          activeModuleId={activeModuleId}
          onOpenMobileDrawer={() => setIsMobileDrawerOpen(true)}
          pendingBookingsCount={pendingBookingsCount}
          onRefresh={() => window.location.reload()}
          onSelectModule={handleSelectModule}
        />

        <main className="p-3 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto space-y-6">
          {/* Sub Navigation banner on mobile for quick feedback */}
          <div className="md:hidden flex items-center justify-between bg-white px-4 py-2.5 rounded-2xl border border-stone-200 shadow-2xs">
            <span className="text-xs font-bold text-stone-600 truncate">
              Phân hệ: <strong className="text-emerald-800">{activeModuleId}</strong>
            </span>
            <button
              onClick={() => setIsMobileDrawerOpen(true)}
              className="text-xs text-emerald-800 font-extrabold hover:underline cursor-pointer"
            >
              Đổi phân hệ ➔
            </button>
          </div>

          {/* Module 1: Tổng quan điều hành (Overview KPI & Route filling) */}
          {(activeModuleId === "overview" || panelTab === "overview") && (
            <div className="space-y-6">
              {/* Executive Stat Banner */}
              <div className="bg-gradient-to-r from-stone-900 via-emerald-950 to-[#1b4332] rounded-3xl p-5 sm:p-8 text-white shadow-xl border border-emerald-900 overflow-hidden">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-center space-x-3 sm:space-x-4">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 shrink-0 bg-white/10 rounded-2xl flex items-center justify-center border border-white/20">
                      <ShieldCheck className="w-5 h-5 sm:w-6 sm:h-6 text-emerald-400" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] bg-emerald-600/80 text-emerald-100 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                          Điều Hành Trực Tuyến
                        </span>
                        <span className="text-white/60 text-[10px]">• Mộc Châu Travel 2.0</span>
                      </div>
                      <h2 className="text-lg sm:text-xl font-black text-white mt-0.5">Tổng Quan Vận Hành & Doanh Số</h2>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleSelectModule("limousine_bookings")}
                      className="px-3.5 py-2 bg-white text-stone-900 rounded-xl text-xs font-bold hover:bg-stone-100 transition-colors cursor-pointer shadow-sm"
                    >
                      Quản lý đơn đặt ({bookings.length})
                    </button>
                    <button
                      onClick={() => handleSelectModule("limousine_seatlock")}
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-sm"
                    >
                      Sơ đồ khóa ghế
                    </button>
                  </div>
                </div>

                {/* 4 Mini Stat cards */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-6">
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/10 flex flex-col justify-between">
                    <p className="text-white/60 text-[11px] font-medium">Doanh thu vé thành công</p>
                    <h4 className="text-xl sm:text-2xl font-black text-amber-300 mt-1 font-mono">
                      {totalRevenue.toLocaleString()}đ
                    </h4>
                    <div className="w-full bg-white/10 h-1 rounded-full mt-2 overflow-hidden">
                      <div className="bg-amber-400 h-full w-2/3 rounded-full" />
                    </div>
                  </div>
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/10 flex flex-col justify-between">
                    <p className="text-white/60 text-[11px] font-medium">Yêu cầu chưa xác nhận</p>
                    <h4 className="text-xl sm:text-2xl font-black text-emerald-300 mt-1 font-mono">
                      {pendingBookingsCount} đơn mới
                    </h4>
                    <div className="w-full bg-white/10 h-1 rounded-full mt-2 overflow-hidden">
                      <div className="bg-emerald-400 h-full w-1/3 rounded-full" />
                    </div>
                  </div>
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/10 flex flex-col justify-between">
                    <p className="text-white/60 text-[11px] font-medium">Số ghế online đã duyệt</p>
                    <h4 className="text-xl sm:text-2xl font-black text-stone-100 mt-1 font-mono">
                      {activeBookedSeatsCount} ghế xếp
                    </h4>
                    <div className="w-full bg-white/10 h-1 rounded-full mt-2 overflow-hidden">
                      <div className="bg-white h-full w-1/2 rounded-full" />
                    </div>
                  </div>
                  <div className="p-4 bg-white/5 rounded-2xl border border-white/10 flex flex-col justify-between">
                    <p className="text-white/60 text-[11px] font-medium">Số ghế bị khóa offline</p>
                    <h4 className="text-xl sm:text-2xl font-black text-teal-300 mt-1 font-mono">
                      {blockedSeats.length} ghế khóa
                    </h4>
                    <div className="w-full bg-white/10 h-1 rounded-full mt-2 overflow-hidden">
                      <div className="bg-teal-300 h-full w-3/4 rounded-full" />
                    </div>
                  </div>
                </div>
              </div>

              {/* REMINDER & BENTO SUMMARY */}
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 shadow-xs">
                <div className="flex items-center gap-2 mb-4">
                  <div className="p-2 bg-emerald-600 rounded-lg text-white">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-black text-emerald-950 text-sm uppercase tracking-tight">NHẮC NHỞ HÀNH TRÌNH HÔM NAY</h3>
                    <p className="text-[10px] text-emerald-700 font-bold">Ngày {new Date().toLocaleDateString('vi-VN')}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="text-[11px] font-black text-emerald-900 border-b border-emerald-100 pb-1 flex items-center gap-1.5">
                      <ArrowRight className="w-3 h-3" /> CHUYẾN XE XUẤT PHÁT
                    </h4>
                    {Object.keys(tripGroups).length > 0 ? (
                      Object.values(tripGroups).map((trip, idx) => (
                        <div key={idx} className="bg-white/70 p-3 rounded-xl border border-emerald-100 text-xs text-stone-800 flex justify-between items-center">
                          <span>Hôm nay có <strong className="text-emerald-700">{trip.count} khách</strong> chuyến <strong className="text-emerald-900">{trip.route}</strong></span>
                          <span className="font-mono bg-emerald-600 text-white px-2 py-0.5 rounded-md font-bold">{trip.time}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-stone-400 italic py-2">Hôm nay chưa có chuyến limousine nào khởi hành.</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-[11px] font-black text-amber-900 border-b border-amber-100 pb-1 flex items-center gap-1.5">
                      <Star className="w-3 h-3" /> ĐẶT PHÒNG & COMBO
                    </h4>
                    {todayCombos.length > 0 ? (
                      todayCombos.map((combo, idx) => (
                        <div key={idx} className="bg-white/70 p-3 rounded-xl border border-amber-100 text-xs text-stone-800">
                          Hôm nay có <strong className="text-amber-700">{combo.passengerName}</strong> đặt combo <strong className="text-amber-900">{combo.accommodationName}</strong> ({combo.roomQuantity} phòng) lúc <strong className="text-stone-900 font-mono italic">{combo.departureTime || "Sáng"}</strong>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-stone-400 italic py-2">Hôm nay chưa có lượt khách đặt combo.</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Bento view */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="bento_route_visualizers">
                <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 flex flex-col justify-between shadow-xs">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-xs font-black uppercase text-stone-500 tracking-wider">Hà Nội ➔ Mộc Châu</span>
                      <span className="p-1.5 bg-emerald-50 text-emerald-700 rounded-lg">
                        <Bus className="w-4 h-4" />
                      </span>
                    </div>
                    <div className="text-2xl font-black text-stone-900 font-mono">{hnMcCount} đơn vé</div>
                    <p className="text-[11px] text-stone-400 mt-1">Khách khởi hành lên cao nguyên</p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-stone-100 flex justify-between text-xs font-bold text-emerald-800">
                    <button onClick={() => { setTypeFilter("limousine"); handleSelectModule("limousine_bookings"); }} className="hover:underline cursor-pointer">
                      Xem danh sách chuyến →
                    </button>
                  </div>
                </div>

                <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 flex flex-col justify-between shadow-xs">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-xs font-black uppercase text-stone-500 tracking-wider">Mộc Châu ➔ Hà Nội</span>
                      <span className="p-1.5 bg-teal-50 text-teal-700 rounded-lg">
                        <Bus className="w-4 h-4" />
                      </span>
                    </div>
                    <div className="text-2xl font-black text-stone-900 font-mono">{mcHnCount} đơn vé</div>
                    <p className="text-[11px] text-stone-400 mt-1">Khách về lại thủ đô</p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-stone-100 flex justify-between text-xs font-bold text-teal-800">
                    <button onClick={() => { setTypeFilter("limousine"); handleSelectModule("limousine_bookings"); }} className="hover:underline cursor-pointer">
                      Xem danh sách chuyến →
                    </button>
                  </div>
                </div>

                <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 flex flex-col justify-between shadow-xs">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-xs font-black uppercase text-stone-500 tracking-wider">Combo Du Lịch</span>
                      <span className="p-1.5 bg-amber-50 text-amber-700 rounded-lg">
                        <Star className="w-4 h-4" />
                      </span>
                    </div>
                    <div className="text-2xl font-black text-stone-900 font-mono">{comboCount} gói</div>
                    <p className="text-[11px] text-stone-400 mt-1">Vé xe Limousine + Phòng Homestay</p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-stone-100 flex justify-between text-xs font-bold text-amber-800">
                    <button onClick={() => { setTypeFilter("combo"); handleSelectModule("limousine_bookings"); }} className="hover:underline cursor-pointer">
                      Xem danh sách combo →
                    </button>
                  </div>
                </div>
              </div>

              {/* Trip Overview Table */}
              <div className="bg-white rounded-2xl shadow-xs border border-stone-200 p-6">
                <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                  <h3 className="text-base font-black text-stone-900">Chi Tiết Tải Trọng Từng Khung Giờ Chạy</h3>
                  <input
                    type="date"
                    value={lockDate}
                    onChange={(e) => setLockDate(e.target.value)}
                    className="px-4 py-2 bg-stone-50 rounded-xl text-xs font-bold border border-stone-200 focus:outline-none"
                  />
                </div>

                {[
                  { label: "Chiều HN - Mộc Châu", route: "Hà Nội - Mộc Châu" },
                  { label: "Chiều Mộc Châu - HN", route: "Mộc Châu - Hà Nội" }
                ].map((direction, idx) => (
                  <div key={`dir-row-${direction.route || idx}-${idx}`} className="mb-6">
                    <h4 className="text-xs font-black text-stone-700 uppercase tracking-wider mb-3 border-b border-stone-100 pb-2">{direction.label}</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
                      {getOfficialSchedulesForRoute(direction.route.split(' - ')[0], direction.route.split(' - ')[1]).map((time, tIdx) => {
                        const bookedCount = bookings.filter(b => b.type === "limousine" && (b.status === "success" || b.status === "completed") && b.departureTime === time && b.travelDate === lockDate && (b.routeSelection === direction.route || b.routeSelection?.replace(' ➔ ', ' - ') === direction.route)).reduce((sum, b) => sum + (b.seatNumbers?.length || 0), 0);
                        const blockedCount = blockedSeats.filter(b => b.tripId === `trip_custom_${time.replace(':', '_')}` && b.travelDate === lockDate).length;
                        const total = 9;
                        const isFull = bookedCount + blockedCount >= total;
                        return (
                          <div key={`limo-grid-${direction.route}-${time}-${tIdx}`} className={`p-3 rounded-xl border text-center transition-all ${isFull ? 'bg-red-50 border-red-200 text-red-900' : 'bg-stone-50 border-stone-200 text-stone-800'}`}>
                            <p className="text-[11px] font-mono font-bold">{time}</p>
                            <p className="text-xs font-black font-mono mt-0.5">{bookedCount + blockedCount} / {total} ghế</p>
                            <span className="text-[9px] text-stone-400 block mt-0.5">{isFull ? "Hết chỗ" : "Còn chỗ"}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

      {panelTab === "bookings" && (
        <div className="mb-6 space-y-4">
          {/* DAILY REMINDER CARD */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              <div className="p-2 bg-emerald-600 rounded-lg text-white">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-black text-emerald-950 text-sm uppercase tracking-tight">NHẮC NHỞ HÀNH TRÌNH HÔM NAY</h3>
                <p className="text-[10px] text-emerald-700 font-bold">Ngày {new Date().toLocaleDateString('vi-VN')}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Bus Reminders */}
              <div className="space-y-2">
                <h4 className="text-[11px] font-black text-emerald-900 border-b border-emerald-100 pb-1 flex items-center gap-1.5">
                  <ArrowRight className="w-3 h-3" /> CHUYẾN XE XUẤT PHÁT
                </h4>
                {Object.keys(tripGroups).length > 0 ? (
                  Object.values(tripGroups).map((trip, idx) => (
                    <div key={idx} className="bg-white/60 p-3 rounded-xl border border-emerald-100 text-xs text-stone-800 flex justify-between items-center">
                      <span>Hôm nay có <strong className="text-emerald-700">{trip.count} khách</strong> đặt vé chuyến <strong className="text-emerald-900">{trip.route}</strong></span>
                      <span className="font-mono bg-emerald-600 text-white px-2 py-0.5 rounded-md font-bold">{trip.time}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-stone-400 italic py-2">Hôm nay chưa có chuyến limousine nào khởi hành.</p>
                )}
              </div>

              {/* Combo Reminders */}
              <div className="space-y-2">
                <h4 className="text-[11px] font-black text-amber-900 border-b border-amber-100 pb-1 flex items-center gap-1.5">
                  <Star className="w-3 h-3" /> ĐẶT PHÒNG & COMBO
                </h4>
                {todayCombos.length > 0 ? (
                  todayCombos.map((combo, idx) => (
                    <div key={idx} className="bg-white/60 p-3 rounded-xl border border-amber-100 text-xs text-stone-800">
                      Hôm nay có <strong className="text-amber-700">{combo.passengerName}</strong> đặt combo <strong className="text-amber-900">{combo.accommodationName}</strong> ({combo.roomQuantity} phòng) vào lúc <strong className="text-stone-900 font-mono italic">{combo.departureTime || "Sáng"}</strong>
                    </div>
                  ))
                ) : (
                  <p className="text-xs text-stone-400 italic py-2">Hôm nay chưa có lượt khách đặt combo.</p>
                )}
              </div>
            </div>
          </div>

          {/* PROFESSIONAL HIGH-TECH ROUTE FILLING STATISTICS BOARD (Bento View) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6" id="bento_route_visualizers">
          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 flex flex-col justify-between shadow-xs">
            <div>
              <span className="text-[10px] font-extrabold text-[#1b4332] uppercase tracking-wide block">Tần suất HN ➔ Mộc Châu</span>
              <p className="text-[11px] text-stone-500 mt-0.5">Lượng khách đi từ thủ đô Hà Nội</p>
            </div>
            <div className="mt-4">
              <div className="flex justify-between items-baseline mb-1">
                <span className="text-stone-900 font-extrabold text-base">{hnMcCount} chuyến duyệt</span>
                <span className="text-stone-400 text-[10px]">Tiêu chuẩn: 7 chuyến / ngày</span>
              </div>
              <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-[#1b4332] h-full rounded-full transition-all" 
                  style={{ width: `${Math.min(100, Math.max(12, hnMcCount * 14))}%` }} 
                />
              </div>
            </div>
          </div>

          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 flex flex-col justify-between shadow-xs">
            <div>
              <span className="text-[10px] font-extrabold text-[#1b4332] uppercase tracking-wide block">Tần suất Mộc Châu ➔ HN</span>
              <p className="text-[11px] text-stone-500 mt-0.5">Lượng khách về lại thủ đô</p>
            </div>
            <div className="mt-4">
              <div className="flex justify-between items-baseline mb-1">
                <span className="text-stone-900 font-extrabold text-base">{mcHnCount} chuyến duyệt</span>
                <span className="text-stone-400 text-[10px]">Tiêu chuẩn: 12 chuyến / ngày</span>
              </div>
              <div className="w-full bg-stone-100 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-[#1b4332] h-full rounded-full transition-all" 
                  style={{ width: `${Math.min(100, Math.max(12, mcHnCount * 8))}%` }} 
                />
              </div>
            </div>
          </div>

          <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 flex items-center justify-between shadow-xs">
            <div className="space-y-1">
              <span className="text-[10px] font-extrabold text-[#1b4332] uppercase tracking-wide block">Tỉ lệ lấp đầy ghế</span>
              <p className="text-[11px] text-stone-500">Toàn bộ các chuyến hôm nay</p>
              <div className="text-stone-900 font-extrabold text-lg mt-2">
                {confirmedTodayCount > 0 ? Math.round((confirmedTodayCount / 38) * 100) : 0}% <span className="text-xs font-normal text-stone-500">ghế đặt</span>
              </div>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-sm border border-emerald-100">
              <TrendingUp className="w-6 h-6 text-emerald-600" />
            </div>
          </div>
        </div>

      {panelTab === "bookings" && (
        /* TAB 1: BOOKING & TICKETS LIST MANAGER */
        <div className="bg-white rounded-2xl shadow-sm border border-stone-200 overflow-hidden" id="bookings_manager_section">
          {/* Controls Bar */}
          <div className="p-4 sm:p-6 bg-stone-50 border-b border-stone-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Tìm tên, SĐT, ghế ngồi, mã vé..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-white border border-stone-200 rounded-xl text-xs font-semibold text-stone-800 placeholder-stone-400 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
              <div className="flex items-center space-x-1.5 bg-white px-3 py-1.5 rounded-xl border border-stone-200">
                <ListFilter className="w-3.5 h-3.5 text-stone-500" />
                <span className="text-[11px] text-stone-500 font-bold">Lọc trạng thái:</span>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="text-xs font-bold text-stone-700 bg-transparent focus:outline-none cursor-pointer"
                >
                  <option value="all">Tất cả ({bookings.length})</option>
                  <option value="pending">Đang chờ ({bookings.filter((b) => b.status === "pending").length})</option>
                  <option value="success">Đã xác nhận ({bookings.filter((b) => b.status === "success").length})</option>
                  <option value="completed">Đã hoàn thành ({bookings.filter((b) => b.status === "completed").length})</option>
                  <option value="cancelled">Đã hủy ({bookings.filter((b) => b.status === "cancelled").length})</option>
                </select>
              </div>

              <div className="flex items-center space-x-1.5 bg-white px-3 py-1.5 rounded-xl border border-stone-200">
                <span className="text-[11px] text-stone-500 font-bold">Dịch vụ:</span>
                <select
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value as any)}
                  className="text-xs font-bold text-stone-700 bg-transparent focus:outline-none cursor-pointer"
                >
                  <option value="all">Tất cả</option>
                  <option value="limousine">Xe Limousine VIP</option>
                  <option value="shared_car">Xe Ghép 7 Chỗ</option>
                  <option value="private_charter">Thuê Xe Riêng</option>
                  <option value="combo">Combo phòng nghỉ</option>
                </select>
              </div>

              <div className="flex items-center space-x-1.5 bg-white px-3 py-1.5 rounded-xl border border-stone-200">
                <span className="text-[11px] text-stone-500 font-bold">Ngày đi:</span>
                <input
                  type="date"
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                  className="text-xs font-semibold text-stone-700 bg-transparent focus:outline-none cursor-pointer"
                />
                {dateFilter && (
                  <button 
                    onClick={() => setDateFilter("")} 
                    className="text-[10px] bg-stone-100 hover:bg-stone-200 px-1 rounded text-stone-600 font-bold font-sans"
                    title="Xóa lọc ngày"
                  >
                    X
                  </button>
                )}
              </div>

              {/* View Mode (Phân nhóm Ngày & Chuyến vs Bảng liên tục) */}
              <div className="flex items-center bg-stone-200/70 p-0.5 rounded-xl border border-stone-300">
                <button
                  onClick={() => setViewMode("grouped")}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    viewMode === "grouped"
                      ? "bg-[#1b4332] text-white shadow-xs"
                      : "text-stone-700 hover:text-stone-900"
                  }`}
                  title="Sắp xếp & phân tách rõ ràng theo từng Ngày và từng Chuyến xe"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Phân theo Ngày & Chuyến</span>
                </button>
                <button
                  onClick={() => setViewMode("table")}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    viewMode === "table"
                      ? "bg-[#1b4332] text-white shadow-xs"
                      : "text-stone-700 hover:text-stone-900"
                  }`}
                  title="Xem dạng danh sách phẳng"
                >
                  <ListFilter className="w-3.5 h-3.5" />
                  <span>Dạng bảng</span>
                </button>
              </div>

              {/* Sort Order Toggle */}
              <button
                onClick={() => setSortOrder(prev => prev === "asc" ? "desc" : "asc")}
                className="px-3 py-1.5 bg-white hover:bg-stone-100 border border-stone-200 rounded-xl text-xs font-bold text-stone-700 flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                title="Thay đổi thứ tự ngày xe chạy"
              >
                <ArrowUpDown className="w-3.5 h-3.5 text-[#1b4332]" />
                <span>{sortOrder === "asc" ? "Ngày: Gần nhất trước ⬆" : "Ngày: Mới nhất trước ⬇"}</span>
              </button>

              <button
                onClick={handleExportCSV}
                className="px-3.5 py-1.5 bg-[#1b4332] hover:bg-emerald-800 text-white rounded-xl text-xs font-bold tracking-wide shadow-xs transition-colors cursor-pointer flex items-center space-x-1"
                title="Tải bảng điều vận danh sách hành khách đi xe Excel"
              >
                <span>📥 Xuất Excel</span>
              </button>
            </div>
          </div>

          {/* Financial & Deposit Quick Summary Strip */}
          {(() => {
            const filteredActive = sortedBookings.filter(b => b.status !== 'cancelled');
            const sumTotalMoney = filteredActive.reduce((acc, b) => acc + (b.totalPrice || 0), 0);
            const sumDepositMoney = filteredActive.reduce((acc, b) => acc + (b.depositAmount || 0), 0);
            const sumRemainingMoney = Math.max(0, sumTotalMoney - sumDepositMoney);

            return (
              <div className="bg-stone-50 border-b border-stone-200/80 px-4 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2 text-stone-700">
                  <Calculator className="w-4 h-4 text-emerald-700" />
                  <span className="font-bold">Tổng kết danh sách đang lọc ({filteredActive.length} đơn hiệu lực / {groupedByDateAndTrip.length} ngày khởi hành):</span>
                </div>
                <div className="flex flex-wrap items-center gap-2 sm:gap-4">
                  <div className="flex items-center gap-1.5 font-mono bg-white px-2.5 py-1 rounded-lg border border-stone-200 shadow-2xs">
                    <span className="text-stone-500 font-sans text-[11px]">Tổng giá vé:</span>
                    <span className="font-black text-stone-900">{sumTotalMoney.toLocaleString()}đ</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-mono bg-emerald-50/80 px-2.5 py-1 rounded-lg border border-emerald-200 shadow-2xs">
                    <span className="text-emerald-800 font-sans text-[11px] font-bold">Đã thu cọc:</span>
                    <span className="font-black text-emerald-900">{sumDepositMoney.toLocaleString()}đ</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-mono bg-red-50/80 px-2.5 py-1 rounded-lg border border-red-200 shadow-2xs">
                    <span className="text-red-700 font-sans text-[11px] font-bold">Còn phải thu:</span>
                    <span className="font-black text-red-700">{sumRemainingMoney.toLocaleString()}đ</span>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Bulk actions banner if any is selected */}
          {selectedBookingIds.length > 0 && (
            <div className="p-4 bg-amber-50 border-b border-amber-100 flex flex-col sm:flex-row justify-between items-center gap-3 animate-fadeIn" id="bulk_actions_bar">
              <div className="flex items-center space-x-2 text-xs font-bold text-amber-900">
                <span className="bg-amber-600 text-white rounded-full w-5 h-5 flex items-center justify-center text-[10px]">
                  {selectedBookingIds.length}
                </span>
                <span>đơn đặt chỗ đang được chọn để xử lý hàng loạt</span>
              </div>
              <div className="flex items-center space-x-2">
                {bulkDeleteConfirm ? (
                  <div className="flex items-center bg-white p-1 rounded-xl border border-red-200">
                    <span className="text-[10px] text-red-600 font-bold px-2">Xóa vĩnh viễn {selectedBookingIds.length} vé?</span>
                    <button
                      onClick={handleBulkDeleteBookings}
                      className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white font-extrabold text-[10px] rounded-lg transition-all cursor-pointer"
                    >
                      Đồng ý xóa
                    </button>
                    <button
                      onClick={() => setBulkDeleteConfirm(false)}
                      className="ml-1 px-2.5 py-1 text-[10px] font-bold text-stone-500 hover:text-stone-700 hover:underline cursor-pointer"
                    >
                      Hủy bỏ
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setBulkDeleteConfirm(true)}
                    className="px-3.5 py-1.5 bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 font-extrabold text-[11px] rounded-xl flex items-center space-x-1 shadow-xs cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-red-600" />
                    <span>Xóa tất cả {selectedBookingIds.length} vé đã chọn</span>
                  </button>
                )}
                
                <button
                  onClick={() => setSelectedBookingIds([])}
                  className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 font-bold text-[11px] rounded-xl transition-colors cursor-pointer"
                >
                  Bỏ chọn tất cả
                </button>
              </div>
            </div>
          )}

          {/* Bookings Table / Cards on mobile */}
          {sortedBookings.length === 0 ? (
            <div className="p-12 text-center text-stone-400">
              <Trash2 className="w-10 h-10 mx-auto text-stone-300 stroke-1 mb-2.5" />
              <p className="text-sm font-semibold">Không tìm thấy yêu cầu đặt chỗ nào thỏa mãn bộ lọc!</p>
            </div>
          ) : (
            <>
              {/* MOBILE CARD VIEW: Designed specifically for smartphones */}
              <div className="md:hidden p-3 space-y-3 bg-stone-50/70" id="operator_bookings_mobile_list">
                {sortedBookings.map((bk, idx) => {
                  const deposit = bk.depositAmount || 0;
                  const remaining = Math.max(0, bk.totalPrice - deposit);
                  const isSuccess = bk.status === "success";
                  const isCompleted = bk.status === "completed";
                  const isCancelled = bk.status === "cancelled";
                  const isPending = bk.status === "pending";

                  return (
                    <div 
                      key={`mob-bk-${bk.id || idx}`}
                      className="bg-white rounded-2xl p-4 border border-stone-200/90 shadow-xs space-y-3"
                    >
                      {/* Top Bar: Code, Date & Status */}
                      <div className="flex items-center justify-between text-xs pb-2 border-b border-stone-100">
                        <div className="flex items-center space-x-1.5 font-mono">
                          <span className="font-black text-[#1b4332]">#{(bk.id || "").toUpperCase().slice(-6)}</span>
                          <span className="text-stone-300">·</span>
                          <span className="text-stone-500 text-[11px] font-sans font-medium">{formatDisplayDate(bk.travelDate)} {bk.departureTime}</span>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                          isSuccess ? "bg-emerald-100 text-emerald-800" :
                          isCompleted ? "bg-blue-100 text-blue-800" :
                          isCancelled ? "bg-stone-100 text-stone-600 line-through" :
                          "bg-amber-100 text-amber-800"
                        }`}>
                          {isSuccess ? "Đã duyệt" : isCompleted ? "Hoàn thành" : isCancelled ? "Đã hủy" : "Chờ xử lý"}
                        </span>
                      </div>

                      {/* Passenger Details & Direct Call Button */}
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-black text-stone-900 text-sm leading-tight">{bk.passengerName}</h4>
                          <p className="text-xs text-stone-500 font-mono mt-0.5">{bk.passengerPhone}</p>
                        </div>
                        <a 
                          href={`tel:${bk.passengerPhone}`}
                          className="px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 rounded-xl text-xs font-bold flex items-center space-x-1"
                        >
                          <Phone className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Gọi khách</span>
                        </a>
                      </div>

                      {/* Route & Vehicle Info */}
                      <div className="text-xs bg-stone-50 p-2.5 rounded-xl border border-stone-100 space-y-1">
                        <div className="flex justify-between text-stone-700">
                          <span className="font-semibold text-stone-500">Hành trình:</span>
                          <span className="font-bold text-stone-900">{bk.routeSelection || bk.accommodationName || "Mộc Châu"}</span>
                        </div>
                        <div className="flex justify-between text-stone-600 text-[11px]">
                          <span>Chỗ ngồi:</span>
                          <span className="font-bold text-emerald-800">
                            {bk.seatNumbers && bk.seatNumbers.length > 0 ? `Ghế: ${bk.seatNumbers.join(", ")}` : `${bk.seatCount || 1} chỗ`}
                          </span>
                        </div>
                        {bk.pickupPoint && (
                          <div className="text-[11px] text-stone-500 truncate">
                            <span className="font-semibold text-stone-600">Đón:</span> {bk.pickupPoint}
                          </div>
                        )}
                      </div>

                      {/* Financial info */}
                      <div className="flex items-center justify-between text-xs pt-1">
                        <div>
                          <span className="text-stone-400 text-[10px] block">Tổng tiền</span>
                          <span className="font-black text-stone-900 font-mono text-sm">{bk.totalPrice.toLocaleString()}đ</span>
                        </div>
                        <div className="text-right">
                          <span className="text-stone-400 text-[10px] block">Cọc / Còn thu</span>
                          <span className="text-xs font-mono">
                            <span className="text-emerald-700 font-bold">{deposit.toLocaleString()}đ</span>
                            <span className="text-stone-300 mx-1">/</span>
                            <span className="text-red-600 font-bold">{remaining.toLocaleString()}đ</span>
                          </span>
                        </div>
                      </div>

                      {/* Driver info if assigned */}
                      {bk.driverName && (
                        <div className="text-[11px] bg-blue-50/80 p-2 rounded-xl border border-blue-200 text-blue-900 flex items-center justify-between">
                          <span>🚗 Lái xe: <strong>{bk.driverName}</strong> ({bk.vehiclePlate || "QT"})</span>
                          {bk.driverPhone && (
                            <a href={`tel:${bk.driverPhone}`} className="underline font-bold text-blue-700">Gọi TX</a>
                          )}
                        </div>
                      )}

                      {/* Quick Mobile Action Buttons */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-stone-100">
                        {isPending && (
                          <button
                            onClick={() => handleUpdateStatus(bk.id, "success")}
                            className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center space-x-1 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Duyệt vé</span>
                          </button>
                        )}
                        {isSuccess && (
                          <button
                            onClick={() => handleUpdateStatus(bk.id, "completed")}
                            className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center space-x-1 cursor-pointer"
                          >
                            <span>Hoàn thành</span>
                          </button>
                        )}
                        <button
                          onClick={() => handleOpenDepositModal(bk)}
                          className="py-2 px-3 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                        >
                          Ghi chú & Cọc
                        </button>
                        <button
                          onClick={() => handleUpdateStatus(bk.id, "cancelled")}
                          className="py-2 px-2.5 border border-stone-200 text-stone-500 hover:text-red-600 rounded-xl text-xs transition-colors cursor-pointer"
                          title="Hủy vé"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* DESKTOP TABLE VIEW: Visible only on md+ screens */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full min-w-[980px]">
                <thead>
                  <tr className="bg-stone-100/80 text-left border-b border-stone-200 text-[11px] text-stone-600 font-extrabold uppercase tracking-wider">
                    <th className="py-3 px-4 text-center w-12">
                      <input
                        type="checkbox"
                        checked={sortedBookings.length > 0 && sortedBookings.every(b => selectedBookingIds.includes(b.id))}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedBookingIds(prev => {
                              const newSelections = [...prev];
                              sortedBookings.forEach(b => {
                                if (!newSelections.includes(b.id)) {
                                  newSelections.push(b.id);
                                }
                              });
                              return newSelections;
                            });
                          } else {
                            setSelectedBookingIds(prev => prev.filter(id => !sortedBookings.some(f => f.id === id)));
                          }
                        }}
                        className="w-4 h-4 text-emerald-600 border-stone-300 rounded focus:ring-emerald-500 cursor-pointer"
                      />
                    </th>
                    <th className="py-3 px-4">Mã đơn & Ngày đặt</th>
                    <th className="py-3 px-6">Hành khách & Liên hệ</th>
                    <th className="py-3 px-6">Hành trình & Ngày giờ đi (ngày/tháng/năm)</th>
                    <th className="py-3 px-6 text-right">Tổng tiền & Cọc / Còn thu</th>
                    <th className="py-3 px-6">Trạng thái</th>
                    <th className="py-3 px-6 text-center">Thao tác duyệt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 text-xs text-stone-700">
                  {viewMode === "grouped" ? (
                    groupedByDateAndTrip.map((dateGroup, dIdx) => (
                      <React.Fragment key={`date-group-${dateGroup.dateISO}-${dIdx}`}>
                        {/* Level 1: Date Group Separator Banner */}
                        <tr className="bg-gradient-to-r from-[#1b4332] via-[#24553f] to-emerald-800 text-white shadow-xs">
                          <td colSpan={7} className="py-2.5 px-4">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <CalendarDays className="w-4 h-4 text-emerald-300" />
                                <span className="font-black text-xs uppercase tracking-wider">
                                  📅 NGÀY ĐI: {dateGroup.dayOfWeek ? `${dateGroup.dayOfWeek}, ` : ""}{dateGroup.dateDisplay}
                                </span>
                                <span className="px-2 py-0.5 rounded-full bg-white/20 text-white font-bold text-[10px]">
                                  {dateGroup.bookingsCount} đơn đặt ({dateGroup.totalSeatsCount} khách/chỗ)
                                </span>
                              </div>
                              <div className="flex items-center gap-3 text-[11px] font-mono">
                                <span className="text-white/90">Tổng tiền: <strong className="text-white font-black">{dateGroup.totalRevenue.toLocaleString()}đ</strong></span>
                                <span className="text-emerald-200">Đã cọc: <strong className="font-bold">{dateGroup.totalDeposit.toLocaleString()}đ</strong></span>
                                <span className="text-amber-200">Còn thu: <strong className="font-black">{dateGroup.totalRemaining.toLocaleString()}đ</strong></span>
                              </div>
                            </div>
                          </td>
                        </tr>

                        {/* Level 2: Trip Group Separator inside Date */}
                        {dateGroup.trips.map((trip, tIdx) => (
                          <React.Fragment key={`trip-group-${dateGroup.dateISO}-${trip.tripKey}-${tIdx}`}>
                            <tr className="bg-emerald-50/90 border-y border-emerald-200 text-emerald-950">
                              <td colSpan={7} className="py-2 px-4">
                                <div className="flex flex-wrap items-center justify-between gap-2">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <Clock className="w-3.5 h-3.5 text-emerald-700" />
                                    <span className="font-black text-xs text-emerald-950 bg-white px-2 py-0.5 rounded-md border border-emerald-300 shadow-2xs font-mono">
                                      ⏰ Chuyến {trip.departureTime}
                                    </span>
                                    <span className="font-extrabold text-xs text-stone-800 flex items-center gap-1">
                                      <Bus className="w-3 h-3 text-stone-500" />
                                      {trip.routeSelection}
                                    </span>
                                    <span className="px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-extrabold text-[9px] uppercase">
                                      {trip.serviceType === "limousine" ? "Limousine 9 chỗ" : trip.serviceType === "shared_car" ? "Xe Ghép 7 Chỗ" : trip.serviceType === "combo" ? "Combo Phòng" : "Thuê Riêng"}
                                    </span>

                                    {/* Lái xe phụ trách chuyến */}
                                    {trip.assignedDriverName ? (
                                      <span className="px-2 py-0.5 rounded-md bg-blue-100/90 text-blue-950 font-bold text-[10px] border border-blue-300 flex items-center gap-1">
                                        <Car className="w-3 h-3 text-blue-700" />
                                        <span>LX: <strong className="font-black text-blue-900">{trip.assignedDriverName}</strong> {trip.assignedDriverPhone ? `(${trip.assignedDriverPhone})` : ""} {trip.assignedVehiclePlate ? `• ${trip.assignedVehiclePlate}` : ""}</span>
                                        <button
                                          onClick={() => handleOpenAssignTripDriver(trip)}
                                          className="ml-1 text-[9px] underline text-blue-700 hover:text-blue-950 font-bold cursor-pointer"
                                          title="Đổi lái xe cho toàn bộ chuyến này"
                                        >
                                          Đổi
                                        </button>
                                      </span>
                                    ) : (
                                      <button
                                        onClick={() => handleOpenAssignTripDriver(trip)}
                                        className="px-2 py-0.5 rounded-md bg-white hover:bg-blue-50 text-blue-700 font-extrabold text-[10px] border border-blue-300 shadow-2xs transition-colors cursor-pointer flex items-center gap-1"
                                        title="Gán lái xe & biển số xe cho toàn bộ khách của chuyến này"
                                      >
                                        <Car className="w-3 h-3 text-blue-600" />
                                        <span>+ Phân Lái Xe Chuyến</span>
                                      </button>
                                    )}
                                  </div>
                                  <div className="flex items-center gap-3 text-[11px] text-stone-600 font-sans flex-wrap">
                                    <span>
                                      <strong className="text-emerald-800 font-bold">{trip.bookings.length}</strong> vé đặt
                                    </span>
                                    <span>•</span>
                                    <span>
                                      Ghế: <strong className="font-mono text-emerald-900">{trip.allSeatNumbers.length > 0 ? trip.allSeatNumbers.join(", ") : `${trip.totalSeats} chỗ`}</strong>
                                    </span>
                                    <span>•</span>
                                    <span className="text-red-700 font-mono font-bold">
                                      Còn thu: {trip.totalRemaining.toLocaleString()}đ
                                    </span>
                                  </div>
                                </div>
                              </td>
                            </tr>

                            {/* Booking Rows for this Trip */}
                            {trip.bookings.map((bk, bIdx) => {
                              const deposit = bk.depositAmount || 0;
                              const remaining = Math.max(0, bk.totalPrice - deposit);

                              return (
                                <tr key={bk.id ? `bk-row-${bk.id}-${bIdx}` : `bk-row-idx-${bIdx}`} className={`hover:bg-stone-50/50 transition-colors ${selectedBookingIds.includes(bk.id) ? "bg-emerald-50/20" : ""}`}>
                                  <td className="py-3.5 px-4 text-center w-12">
                                    <input
                                      type="checkbox"
                                      checked={selectedBookingIds.includes(bk.id)}
                                      onChange={(e) => {
                                        if (e.target.checked) {
                                          setSelectedBookingIds(prev => [...prev, bk.id]);
                                        } else {
                                          setSelectedBookingIds(prev => prev.filter(id => id !== bk.id));
                                        }
                                      }}
                                      className="w-4 h-4 text-emerald-600 border-stone-300 rounded focus:ring-emerald-500 cursor-pointer"
                                    />
                                  </td>
                                  <td className="py-3.5 px-4 font-mono">
                                    <span className="font-extrabold text-[#1b4332] block">#{(bk.id || "").replace("bk_", "").toUpperCase()}</span>
                                    <span className="text-[10px] text-stone-500 mt-0.5 block">Đơn ngày: {formatDisplayDate(bk.bookingDate)}</span>
                                  </td>
                                  <td className="py-3.5 px-6">
                                    <div className="space-y-1">
                                      <p className="font-extrabold text-[#111]">{bk.passengerName}</p>
                                      <p className="font-mono text-[10px] text-stone-500 flex items-center gap-0.5">
                                        <Phone className="w-3 h-3 text-stone-400" />
                                        {bk.passengerPhone}
                                      </p>
                                      <div className="flex items-center gap-1.5 pt-0.5">
                                        <a 
                                          href={`sms:${bk.passengerPhone}?body=${encodeURIComponent(`[Limousine Moc Chau] Xac nhan thanh cong ve xe #${(bk.id||'').replace('bk_','').toUpperCase()} cho quy khach ${bk.passengerName}. Chuyen ${formatDisplayDate(bk.travelDate)} luc ${bk.departureTime||''} (${(bk.seatNumbers||[]).join(', ')}). Hotline: 0971050324`)}`}
                                          className="text-[9px] bg-stone-100 hover:bg-emerald-50 text-stone-600 hover:text-emerald-700 font-bold px-1.5 py-0.5 rounded border border-stone-200 transition-colors"
                                          title="Gửi SMS xác nhận đến điện thoại khách"
                                        >
                                          SMS
                                        </a>
                                        <a 
                                          href={`https://zalo.me/${bk.passengerPhone.replace(/^0/, '84')}`}
                                          target="_blank" 
                                          rel="noreferrer"
                                          className="text-[9px] bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold px-1.5 py-0.5 rounded border border-blue-200 transition-colors"
                                          title="Nhắn tin Zalo cho khách"
                                        >
                                          Zalo
                                        </a>
                                      </div>
                                    </div>
                                  </td>
                                  <td className="py-3.5 px-6">
                                    {bk.type === "limousine" && (
                                      <div className="space-y-1">
                                        <p className="font-extrabold text-stone-800 flex items-center gap-1.5">
                                          <span className="px-1.5 py-0.5 text-[9px] bg-emerald-100 text-emerald-800 font-bold rounded-md">
                                            XE LIMOUSINE
                                          </span>
                                          <span>Tuyến: {bk.routeSelection}</span>
                                        </p>
                                        <p className="text-stone-600 font-sans text-[11px]">
                                          Ngày đi: <strong className="text-emerald-900 font-extrabold bg-emerald-50 px-1 py-0.5 rounded border border-emerald-200">{formatDisplayDate(bk.travelDate)}</strong> | Giờ: <strong className="text-stone-900 font-extrabold">{bk.departureTime}</strong>
                                        </p>
                                        <p className="text-[10px] text-emerald-700 font-bold">
                                          Ghế đặt: {bk.seatNumbers?.join(", ")}
                                        </p>
                                      </div>
                                    )}
                                    {bk.type === "shared_car" && (
                                      <div className="space-y-1">
                                        <p className="font-extrabold text-stone-800 flex items-center gap-1.5">
                                          <span className="px-1.5 py-0.5 text-[9px] bg-teal-100 text-teal-800 font-bold rounded-md">
                                            XE GHÉP 7 CHỖ
                                          </span>
                                          <span>Tuyến: {bk.routeSelection}</span>
                                        </p>
                                        <p className="text-stone-600 font-sans text-[11px]">
                                          Ngày đi: <strong className="text-teal-900 font-extrabold bg-teal-50 px-1 py-0.5 rounded border border-teal-200">{formatDisplayDate(bk.travelDate)}</strong> | Giờ: <strong className="text-stone-900 font-extrabold">{bk.departureTime}</strong>
                                        </p>
                                        <p className="text-[10px] text-teal-700 font-bold">
                                          Ghế đặt: {bk.seatNumbers?.join(", ")}
                                        </p>
                                      </div>
                                    )}
                                    {bk.type === "private_charter" && (
                                      <div className="space-y-1">
                                        <p className="font-extrabold text-stone-800 flex items-center gap-1.5">
                                          <span className="px-1.5 py-0.5 text-[9px] bg-indigo-100 text-indigo-800 font-bold rounded-md">
                                            THUÊ XE RIÊNG
                                          </span>
                                          <span>Tuyến: {bk.routeSelection || "Theo yêu cầu"}</span>
                                        </p>
                                        <p className="text-stone-600 font-sans text-[11px]">
                                          Ngày đi: <strong className="text-indigo-900 font-extrabold bg-indigo-50 px-1 py-0.5 rounded border border-indigo-200">{formatDisplayDate(bk.travelDate)}</strong> | Giờ: <strong className="text-stone-900 font-extrabold">{bk.departureTime || '-'}</strong>
                                        </p>
                                        <p className="text-[10px] text-indigo-700 font-bold">
                                          Sức chứa: {bk.seatCount || "7"} chỗ
                                        </p>
                                      </div>
                                    )}
                                    {bk.type === "combo" && (
                                      <div className="space-y-1">
                                        <p className="font-extrabold text-stone-800 flex items-center gap-1.5">
                                          <span className="px-1.5 py-0.5 text-[9px] bg-amber-100 text-amber-800 font-bold rounded-md">
                                            COMBO
                                          </span>
                                          <span>{bk.accommodationName}</span>
                                        </p>
                                        <p className="text-stone-500 font-sans">
                                          Loại phòng: {bk.roomTypeName} ({bk.roomQuantity} phòng x {bk.nights} đêm)
                                        </p>
                                        <p className="text-[11px] text-amber-900 font-bold">
                                          Ngày đi xe khứ hồi: <span className="bg-amber-100/80 px-1 py-0.5 rounded border border-amber-300 font-extrabold">{formatDisplayDate(bk.travelDate)}</span>
                                        </p>
                                      </div>
                                    )}
                                    <span className="text-[9px] text-stone-400 block mt-1.5">Đón: {bk.pickupPoint} ➜ Trả: {bk.dropoffPoint}</span>

                                    {/* Thông tin Lái xe phụ trách khách này */}
                                    {bk.driverName ? (
                                      <div className="mt-1.5 p-1.5 bg-blue-50/90 border border-blue-200 rounded-lg text-[10px] text-blue-950 font-medium flex items-center justify-between gap-1 flex-wrap">
                                        <div className="flex items-center gap-1.5 flex-wrap">
                                          <span className="font-black text-blue-800 flex items-center gap-1">
                                            <Car className="w-3 h-3 text-blue-700" /> Lái xe:
                                          </span>
                                          <strong className="text-blue-950 font-extrabold">{bk.driverName}</strong>
                                          {bk.driverPhone && (
                                            <a 
                                              href={`tel:${bk.driverPhone}`} 
                                              className="text-blue-700 hover:text-blue-950 underline font-mono flex items-center gap-0.5 font-bold"
                                              title="Gọi điện cho lái xe"
                                            >
                                              📞 {bk.driverPhone}
                                            </a>
                                          )}
                                          {bk.vehiclePlate && (
                                            <span className="px-1.5 py-0.2 bg-white rounded border border-blue-300 font-mono font-bold text-stone-800 text-[9px]">
                                              Biển số: {bk.vehiclePlate}
                                            </span>
                                          )}
                                        </div>
                                        <button
                                          onClick={() => handleOpenDepositModal(bk)}
                                          className="text-[9px] text-blue-700 hover:text-blue-900 font-bold underline cursor-pointer shrink-0 ml-auto"
                                          title="Đổi thông tin lái xe cho khách này"
                                        >
                                          Đổi
                                        </button>
                                      </div>
                                    ) : (
                                      <div className="mt-1 flex items-center gap-1">
                                        <button
                                          onClick={() => handleOpenDepositModal(bk)}
                                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-800 text-[10px] font-bold transition-colors cursor-pointer"
                                          title="Phân lái xe và biển số xe đưa đón khách này"
                                        >
                                          <Car className="w-3 h-3 text-blue-600" />
                                          <span>+ Gán Lái Xe</span>
                                        </button>
                                      </div>
                                    )}

                                    {/* Ghi chú điều hành / Nhà xe */}
                                    {bk.operatorNotes && (
                                      <div className="mt-1.5 p-1.5 bg-amber-50/90 border border-amber-200 rounded-lg text-[10px] text-amber-950 font-medium flex items-start gap-1">
                                        <span className="font-black text-amber-800 shrink-0">📌 Nhà xe:</span>
                                        <span>{bk.operatorNotes}</span>
                                      </div>
                                    )}

                                    {/* Ghi chú khách gửi */}
                                    {bk.notes && (
                                      <div className="mt-1 p-1 bg-stone-50 border border-stone-200 rounded text-[10px] text-stone-600">
                                        <span className="font-bold text-stone-700">💬 Khách dặn:</span> {bk.notes}
                                      </div>
                                    )}
                                  </td>
                                  <td className="py-3.5 px-6 text-right font-mono">
                                    <div className="space-y-1">
                                      <div className="font-black text-xs text-stone-900">
                                        {bk.totalPrice.toLocaleString()}đ
                                      </div>
                                      
                                      {/* Tiền đã cọc */}
                                      <div>
                                        {deposit > 0 ? (
                                          <span className="inline-block px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                                            Đã cọc: {deposit.toLocaleString()}đ
                                          </span>
                                        ) : (
                                          <span className="inline-block px-1.5 py-0.5 rounded bg-stone-100 text-stone-500 text-[10px]">
                                            Chưa cọc: 0đ
                                          </span>
                                        )}
                                      </div>

                                      {/* Còn phải thu */}
                                      {remaining <= 0 ? (
                                        <span className="block text-[10px] font-extrabold text-emerald-700">
                                          ✓ Đã thu đủ
                                        </span>
                                      ) : (
                                        <span className="block text-[11px] font-black text-red-600">
                                          Còn thu: {remaining.toLocaleString()}đ
                                        </span>
                                      )}

                                      {/* Nút bấm mở pop-up sửa nhanh cọc & ghi chú & lái xe */}
                                      <button
                                        onClick={() => handleOpenDepositModal(bk)}
                                        className="mt-1 inline-flex items-center gap-1 text-[10px] text-blue-600 hover:text-blue-800 hover:underline font-bold transition-colors cursor-pointer"
                                        title="Cập nhật lái xe, tiền cọc, số tiền phải thu và ghi chú điều hành"
                                      >
                                        <Edit3 className="w-2.5 h-2.5" />
                                        <span>Sửa cọc / Lái xe</span>
                                      </button>
                                    </div>
                                  </td>
                                  <td className="py-3.5 px-6">
                                    {bk.status === "pending" && (
                                      <span className="px-2 py-1 bg-yellow-50 text-yellow-700 border border-yellow-200 rounded-full font-bold text-[10px]">
                                        Đang Chờ
                                      </span>
                                    )}
                                    {bk.status === 'pending' && bk.paymentReported && <span className="block mt-1 text-[10px] font-bold bg-amber-100 text-amber-950 rounded px-2 py-1">⚡ Khách báo đã chuyển cọc — Kiểm tra ngân hàng</span>}
                                    {bk.status === "success" && (
                                      <span className="px-2 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full font-bold text-[10px]">
                                        Đã Đi / OK
                                      </span>
                                    )}
                                    {bk.status === "completed" && (
                                      <span className="px-2 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded-full font-bold text-[10px]">
                                        Đã Đi / Xong
                                      </span>
                                    )}
                                    {bk.status === "cancelled" && (
                                      <span className="px-2 py-1 bg-stone-100 text-stone-500 border border-stone-200 rounded-full font-bold text-[10px]">
                                        Đã Hủy
                                      </span>
                                    )}
                                  </td>
                                  <td className="py-3.5 px-6">
                                    <div className="flex items-center justify-center gap-1.5">
                                      {bk.status === "pending" && (
                                        <>
                                          <button
                                            onClick={() => handleUpdateStatus(bk.id, "success")}
                                            className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[10px] uppercase transition-all flex items-center gap-1 cursor-pointer"
                                            title="Xác nhận thanh toán thành công & tích điểm cho khách"
                                          >
                                            <Check className="w-3.5 h-3.5" />
                                            Duyệt Đơn
                                          </button>
                                          <button
                                            onClick={() => handleUpdateStatus(bk.id, "cancelled")}
                                            className="px-2.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-lg font-bold text-[10px] uppercase transition-all flex items-center gap-1 cursor-pointer"
                                            title="Hủy chuyến giữ chỗ này"
                                          >
                                            <X className="w-3.5 h-3.5" />
                                            Hủy Đơn
                                          </button>
                                        </>
                                      )}
                                      {bk.status === "success" && (
                                        <>
                                          <button
                                            onClick={() => handleUpdateStatus(bk.id, "completed")}
                                            className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-[10px] font-bold cursor-pointer transition-colors"
                                            title="Đánh dấu chuyến đi đã hoàn thành"
                                          >
                                            Hoàn thành
                                          </button>
                                          <button
                                            onClick={() => handleUpdateStatus(bk.id, "cancelled")}
                                            className="px-2 py-1 border border-stone-200 text-stone-400 rounded-md hover:text-red-500 hover:border-red-200 text-[10px] cursor-pointer"
                                            title="Hủy chuyến"
                                          >
                                            Hủy đơn
                                          </button>
                                        </>
                                      )}
                                      {bk.status === "completed" && (
                                        <button
                                          onClick={() => handleUpdateStatus(bk.id, "success")}
                                          className="px-2 py-1 border border-stone-200 text-stone-500 rounded-md hover:text-[#1b4332] hover:bg-emerald-50 text-[10px] cursor-pointer"
                                          title="Khôi phục trạng thái Đã Duyệt"
                                        >
                                          Khôi phục 'Duyệt'
                                        </button>
                                      )}
                                      {bk.status === "cancelled" && (
                                        <button
                                          onClick={() => handleUpdateStatus(bk.id, "pending")}
                                          className="px-2 py-1 border border-stone-200 text-stone-500 rounded-md hover:text-[#1b4332] hover:bg-emerald-50 text-[10px] cursor-pointer"
                                        >
                                          Khôi phục 'Chờ'
                                        </button>
                                      )}
                                      
                                      {/* Permanent Storage Deletion Button */}
                                      {deleteConfirmId === bk.id ? (
                                        <div className="flex items-center bg-red-100 border border-red-300 p-0.5 rounded-lg animate-fadeIn ml-1 text-[10px]">
                                          <button
                                            type="button"
                                            onClick={() => handleDeleteBooking(bk.id)}
                                            className="px-1.5 py-1 bg-red-700 hover:bg-red-800 text-white font-extrabold rounded-md shadow-xs transition-colors cursor-pointer text-[9px]"
                                          >
                                            Xóa thật
                                          </button>
                                          <button
                                            type="button"
                                            onClick={() => setDeleteConfirmId(null)}
                                            className="ml-1 text-[9px] font-bold text-stone-600 hover:text-stone-900 px-0.5 hover:underline cursor-pointer"
                                          >
                                            Hủy
                                          </button>
                                        </div>
                                      ) : (
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setDeleteConfirmId(bk.id);
                                            setTimeout(() => {
                                              setDeleteConfirmId(prev => prev === bk.id ? null : prev);
                                            }, 4000);
                                          }}
                                          className="p-1 px-1.5 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 rounded-lg transition-colors cursor-pointer flex items-center gap-0.5 ml-1"
                                          title="Xóa vĩnh viễn vé này"
                                        >
                                          <Trash2 className="w-3.5 h-3.5 text-red-600" />
                                          <span className="text-[10px] font-bold">Xóa vé</span>
                                        </button>
                                      )}
                                    </div>
                                  </td>
                                </tr>
                              );
                            })}
                          </React.Fragment>
                        ))}
                      </React.Fragment>
                    ))
                  ) : (
                    sortedBookings.map((bk, idx) => {
                      const deposit = bk.depositAmount || 0;
                      const remaining = Math.max(0, bk.totalPrice - deposit);

                      return (
                        <tr key={bk.id ? `bk-flat-${bk.id}-${idx}` : `bk-flat-idx-${idx}`} className={`hover:bg-stone-50/50 transition-colors ${selectedBookingIds.includes(bk.id) ? "bg-emerald-50/20" : ""}`}>
                          <td className="py-3.5 px-4 text-center w-12">
                            <input
                              type="checkbox"
                              checked={selectedBookingIds.includes(bk.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedBookingIds(prev => [...prev, bk.id]);
                                } else {
                                  setSelectedBookingIds(prev => prev.filter(id => id !== bk.id));
                                }
                              }}
                              className="w-4 h-4 text-emerald-600 border-stone-300 rounded focus:ring-emerald-500 cursor-pointer"
                            />
                          </td>
                          <td className="py-3.5 px-4 font-mono">
                            <span className="font-extrabold text-[#1b4332] block">#{(bk.id || "").replace("bk_", "").toUpperCase()}</span>
                            <span className="text-[10px] text-stone-500 mt-0.5 block">Đơn ngày: {formatDisplayDate(bk.bookingDate)}</span>
                          </td>
                          <td className="py-3.5 px-6">
                            <div className="space-y-1">
                              <p className="font-extrabold text-[#111]">{bk.passengerName}</p>
                              <p className="font-mono text-[10px] text-stone-500 flex items-center gap-0.5">
                                <Phone className="w-3 h-3 text-stone-400" />
                                {bk.passengerPhone}
                              </p>
                              <div className="flex items-center gap-1.5 pt-0.5">
                                <a 
                                  href={`sms:${bk.passengerPhone}?body=${encodeURIComponent(`[Limousine Moc Chau] Xac nhan thanh cong ve xe #${(bk.id||'').replace('bk_','').toUpperCase()} cho quy khach ${bk.passengerName}. Chuyen ${formatDisplayDate(bk.travelDate)} luc ${bk.departureTime||''} (${(bk.seatNumbers||[]).join(', ')}). Hotline: 0971050324`)}`}
                                  className="text-[9px] bg-stone-100 hover:bg-emerald-50 text-stone-600 hover:text-emerald-700 font-bold px-1.5 py-0.5 rounded border border-stone-200 transition-colors"
                                  title="Gửi SMS xác nhận đến điện thoại khách"
                                >
                                  SMS
                                </a>
                                <a 
                                  href={`https://zalo.me/${bk.passengerPhone.replace(/^0/, '84')}`}
                                  target="_blank" 
                                  rel="noreferrer"
                                  className="text-[9px] bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold px-1.5 py-0.5 rounded border border-blue-200 transition-colors"
                                  title="Nhắn tin Zalo cho khách"
                                >
                                  Zalo
                                </a>
                              </div>
                            </div>
                          </td>
                          <td className="py-3.5 px-6">
                            {bk.type === "limousine" && (
                              <div className="space-y-1">
                                <p className="font-extrabold text-stone-800 flex items-center gap-1.5">
                                  <span className="px-1.5 py-0.5 text-[9px] bg-emerald-100 text-emerald-800 font-bold rounded-md">
                                    XE LIMOUSINE
                                  </span>
                                  <span>Tuyến: {bk.routeSelection}</span>
                                </p>
                                <p className="text-stone-600 font-sans text-[11px]">
                                  Ngày đi: <strong className="text-emerald-900 font-extrabold bg-emerald-50 px-1 py-0.5 rounded border border-emerald-200">{formatDisplayDate(bk.travelDate)}</strong> | Giờ: <strong className="text-stone-900 font-extrabold">{bk.departureTime}</strong>
                                </p>
                                <p className="text-[10px] text-emerald-700 font-bold">
                                  Ghế đặt: {bk.seatNumbers?.join(", ")}
                                </p>
                              </div>
                            )}
                            {bk.type === "shared_car" && (
                              <div className="space-y-1">
                                <p className="font-extrabold text-stone-800 flex items-center gap-1.5">
                                  <span className="px-1.5 py-0.5 text-[9px] bg-teal-100 text-teal-800 font-bold rounded-md">
                                    XE GHÉP 7 CHỖ
                                  </span>
                                  <span>Tuyến: {bk.routeSelection}</span>
                                </p>
                                <p className="text-stone-600 font-sans text-[11px]">
                                  Ngày đi: <strong className="text-teal-900 font-extrabold bg-teal-50 px-1 py-0.5 rounded border border-teal-200">{formatDisplayDate(bk.travelDate)}</strong> | Giờ: <strong className="text-stone-900 font-extrabold">{bk.departureTime}</strong>
                                </p>
                                <p className="text-[10px] text-teal-700 font-bold">
                                  Ghế đặt: {bk.seatNumbers?.join(", ")}
                                </p>
                              </div>
                            )}
                            {bk.type === "private_charter" && (
                              <div className="space-y-1">
                                <p className="font-extrabold text-stone-800 flex items-center gap-1.5">
                                  <span className="px-1.5 py-0.5 text-[9px] bg-indigo-100 text-indigo-800 font-bold rounded-md">
                                    THUÊ XE RIÊNG
                                  </span>
                                  <span>Tuyến: {bk.routeSelection || "Theo yêu cầu"}</span>
                                </p>
                                <p className="text-stone-600 font-sans text-[11px]">
                                  Ngày đi: <strong className="text-indigo-900 font-extrabold bg-indigo-50 px-1 py-0.5 rounded border border-indigo-200">{formatDisplayDate(bk.travelDate)}</strong> | Giờ: <strong className="text-stone-900 font-extrabold">{bk.departureTime || '-'}</strong>
                                </p>
                                <p className="text-[10px] text-indigo-700 font-bold">
                                  Sức chứa: {bk.seatCount || "7"} chỗ
                                </p>
                              </div>
                            )}
                            {bk.type === "combo" && (
                              <div className="space-y-1">
                                <p className="font-extrabold text-stone-800 flex items-center gap-1.5">
                                  <span className="px-1.5 py-0.5 text-[9px] bg-amber-100 text-amber-800 font-bold rounded-md">
                                    COMBO
                                  </span>
                                  <span>{bk.accommodationName}</span>
                                </p>
                                <p className="text-stone-500 font-sans">
                                  Loại phòng: {bk.roomTypeName} ({bk.roomQuantity} phòng x {bk.nights} đêm)
                                </p>
                                <p className="text-[11px] text-amber-900 font-bold">
                                  Ngày đi xe khứ hồi: <span className="bg-amber-100/80 px-1 py-0.5 rounded border border-amber-300 font-extrabold">{formatDisplayDate(bk.travelDate)}</span>
                                </p>
                              </div>
                            )}
                            <span className="text-[9px] text-stone-400 block mt-1.5">Đón: {bk.pickupPoint} ➜ Trả: {bk.dropoffPoint}</span>

                            {/* Thông tin Lái xe phụ trách khách này */}
                            {bk.driverName ? (
                              <div className="mt-1.5 p-1.5 bg-blue-50/90 border border-blue-200 rounded-lg text-[10px] text-blue-950 font-medium flex items-center justify-between gap-1 flex-wrap">
                                <div className="flex items-center gap-1.5 flex-wrap">
                                  <span className="font-black text-blue-800 flex items-center gap-1">
                                    <Car className="w-3 h-3 text-blue-700" /> Lái xe:
                                  </span>
                                  <strong className="text-blue-950 font-extrabold">{bk.driverName}</strong>
                                  {bk.driverPhone && (
                                    <a 
                                      href={`tel:${bk.driverPhone}`} 
                                      className="text-blue-700 hover:text-blue-950 underline font-mono flex items-center gap-0.5 font-bold"
                                      title="Gọi điện cho lái xe"
                                    >
                                      📞 {bk.driverPhone}
                                    </a>
                                  )}
                                  {bk.vehiclePlate && (
                                    <span className="px-1.5 py-0.2 bg-white rounded border border-blue-300 font-mono font-bold text-stone-800 text-[9px]">
                                      Biển số: {bk.vehiclePlate}
                                    </span>
                                  )}
                                </div>
                                <button
                                  onClick={() => handleOpenDepositModal(bk)}
                                  className="text-[9px] text-blue-700 hover:text-blue-900 font-bold underline cursor-pointer shrink-0 ml-auto"
                                  title="Đổi thông tin lái xe cho khách này"
                                >
                                  Đổi
                                </button>
                              </div>
                            ) : (
                              <div className="mt-1 flex items-center gap-1">
                                <button
                                  onClick={() => handleOpenDepositModal(bk)}
                                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-800 text-[10px] font-bold transition-colors cursor-pointer"
                                  title="Phân lái xe và biển số xe đưa đón khách này"
                                >
                                  <Car className="w-3 h-3 text-blue-600" />
                                  <span>+ Gán Lái Xe</span>
                                </button>
                              </div>
                            )}

                            {/* Ghi chú điều hành / Nhà xe */}
                            {bk.operatorNotes && (
                              <div className="mt-1.5 p-1.5 bg-amber-50/90 border border-amber-200 rounded-lg text-[10px] text-amber-950 font-medium flex items-start gap-1">
                                <span className="font-black text-amber-800 shrink-0">📌 Nhà xe:</span>
                                <span>{bk.operatorNotes}</span>
                              </div>
                            )}

                            {/* Ghi chú khách gửi */}
                            {bk.notes && (
                              <div className="mt-1 p-1 bg-stone-50 border border-stone-200 rounded text-[10px] text-stone-600">
                                <span className="font-bold text-stone-700">💬 Khách dặn:</span> {bk.notes}
                              </div>
                            )}
                          </td>
                          <td className="py-3.5 px-6 text-right font-mono">
                            <div className="space-y-1">
                              <div className="font-black text-xs text-stone-900">
                                {bk.totalPrice.toLocaleString()}đ
                              </div>
                              
                              {/* Tiền đã cọc */}
                              <div>
                                {deposit > 0 ? (
                                  <span className="inline-block px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                                    Đã cọc: {deposit.toLocaleString()}đ
                                  </span>
                                ) : (
                                  <span className="inline-block px-1.5 py-0.5 rounded bg-stone-100 text-stone-500 text-[10px]">
                                    Chưa cọc: 0đ
                                  </span>
                                )}
                              </div>

                              {/* Còn phải thu */}
                              {remaining <= 0 ? (
                                <span className="block text-[10px] font-extrabold text-emerald-700">
                                  ✓ Đã thu đủ
                                </span>
                              ) : (
                                <span className="block text-[11px] font-black text-red-600">
                                  Còn thu: {remaining.toLocaleString()}đ
                                </span>
                              )}

                              {/* Nút bấm mở pop-up sửa nhanh cọc & ghi chú */}
                              <button
                                onClick={() => handleOpenDepositModal(bk)}
                                className="mt-1 inline-flex items-center gap-1 text-[10px] text-blue-600 hover:text-blue-800 hover:underline font-bold transition-colors cursor-pointer"
                                title="Cập nhật lái xe, tiền cọc, số tiền phải thu và ghi chú điều hành"
                              >
                                <Edit3 className="w-2.5 h-2.5" />
                                <span>Sửa cọc / Lái xe</span>
                              </button>
                            </div>
                          </td>
                          <td className="py-3.5 px-6">
                            {bk.status === "pending" && (
                              <span className="px-2 py-1 bg-yellow-50 text-yellow-700 border border-yellow-200 rounded-full font-bold text-[10px]">
                                Đang Chờ
                              </span>
                            )}
                            {bk.status === 'pending' && bk.paymentReported && <span className="block mt-1 text-[10px] font-bold bg-amber-100 text-amber-950 rounded px-2 py-1">⚡ Khách báo đã chuyển cọc — Kiểm tra ngân hàng</span>}
                            {bk.status === "success" && (
                              <span className="px-2 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full font-bold text-[10px]">
                                Đã Đi / OK
                              </span>
                            )}
                            {bk.status === "completed" && (
                              <span className="px-2 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded-full font-bold text-[10px]">
                                Đã Đi / Xong
                              </span>
                            )}
                            {bk.status === "cancelled" && (
                              <span className="px-2 py-1 bg-stone-100 text-stone-500 border border-stone-200 rounded-full font-bold text-[10px]">
                                Đã Hủy
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-6">
                            <div className="flex items-center justify-center gap-1.5">
                              {bk.status === "pending" && (
                                <>
                                  <button
                                    onClick={() => handleUpdateStatus(bk.id, "success")}
                                    className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[10px] uppercase transition-all flex items-center gap-1 cursor-pointer"
                                    title="Xác nhận thanh toán thành công & tích điểm cho khách"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    Duyệt Đơn
                                  </button>
                                  <button
                                    onClick={() => handleUpdateStatus(bk.id, "cancelled")}
                                    className="px-2.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-lg font-bold text-[10px] uppercase transition-all flex items-center gap-1 cursor-pointer"
                                    title="Hủy chuyến giữ chỗ này"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                    Hủy Đơn
                                  </button>
                                </>
                              )}
                              {bk.status === "success" && (
                                <>
                                  <button
                                    onClick={() => handleUpdateStatus(bk.id, "completed")}
                                    className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-[10px] font-bold cursor-pointer transition-colors"
                                    title="Đánh dấu chuyến đi đã hoàn thành"
                                  >
                                    Hoàn thành
                                  </button>
                                  <button
                                    onClick={() => handleUpdateStatus(bk.id, "cancelled")}
                                    className="px-2 py-1 border border-stone-200 text-stone-400 rounded-md hover:text-red-500 hover:border-red-200 text-[10px] cursor-pointer"
                                    title="Hủy chuyến"
                                  >
                                    Hủy đơn
                                  </button>
                                </>
                              )}
                              {bk.status === "completed" && (
                                <button
                                  onClick={() => handleUpdateStatus(bk.id, "success")}
                                  className="px-2 py-1 border border-stone-200 text-stone-500 rounded-md hover:text-[#1b4332] hover:bg-emerald-50 text-[10px] cursor-pointer"
                                  title="Khôi phục trạng thái Đã Duyệt"
                                >
                                  Khôi phục 'Duyệt'
                                </button>
                              )}
                              {bk.status === "cancelled" && (
                                <button
                                  onClick={() => handleUpdateStatus(bk.id, "pending")}
                                  className="px-2 py-1 border border-stone-200 text-stone-500 rounded-md hover:text-[#1b4332] hover:bg-emerald-50 text-[10px] cursor-pointer"
                                >
                                  Khôi phục 'Chờ'
                                </button>
                              )}
                              
                              {/* Permanent Storage Deletion Button */}
                              {deleteConfirmId === bk.id ? (
                                <div className="flex items-center bg-red-100 border border-red-300 p-0.5 rounded-lg animate-fadeIn ml-1 text-[10px]">
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteBooking(bk.id)}
                                    className="px-1.5 py-1 bg-red-700 hover:bg-red-800 text-white font-extrabold rounded-md shadow-xs transition-colors cursor-pointer text-[9px]"
                                  >
                                    Xóa thật
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setDeleteConfirmId(null)}
                                    className="ml-1 text-[9px] font-bold text-stone-600 hover:text-stone-900 px-0.5 hover:underline cursor-pointer"
                                  >
                                    Hủy
                                  </button>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setDeleteConfirmId(bk.id);
                                    setTimeout(() => {
                                      setDeleteConfirmId(prev => prev === bk.id ? null : prev);
                                    }, 4000);
                                  }}
                                  className="p-1 px-1.5 bg-red-50 hover:bg-red-100 text-red-600 border border-red-200 rounded-lg transition-colors cursor-pointer flex items-center gap-0.5 ml-1"
                                  title="Xóa vĩnh viễn vé này"
                                >
                                  <Trash2 className="w-3.5 h-3.5 text-red-600" />
                                  <span className="text-[10px] font-bold">Xóa vé</span>
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}
        </div>
      )}

      {/* Quick Deposit & Operator Notes Modal */}
          {editingDepositBooking && (
            <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-[120] animate-fade-in text-left">
              <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-stone-200 flex flex-col animate-scale-up">
                <div className="bg-[#1b4332] text-white p-5 relative">
                  <button 
                    onClick={() => setEditingDepositBooking(null)}
                    className="absolute top-4 right-4 text-white/80 hover:text-white bg-white/10 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold cursor-pointer transition-colors"
                  >
                    ✕
                  </button>
                  <div className="flex items-center gap-2">
                    <Banknote className="w-5 h-5 text-emerald-400" />
                    <span className="text-[10px] bg-emerald-400 text-stone-950 font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                      QUẢN LÝ TIỀN CỌC & GHI CHÚ
                    </span>
                  </div>
                  <h3 className="text-lg font-black tracking-tight mt-2 text-white">
                    Vé #{editingDepositBooking.id.replace("bk_", "").toUpperCase()} - {editingDepositBooking.passengerName}
                  </h3>
                  <p className="text-emerald-100 text-xs mt-0.5">
                    SĐT: <strong className="text-white">{editingDepositBooking.passengerPhone}</strong> | Tuyến: {editingDepositBooking.routeSelection || editingDepositBooking.accommodationName || "Xe riêng"} ({editingDepositBooking.travelDate} lúc {editingDepositBooking.departureTime || '-'})
                  </p>
                </div>

                <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
                  {/* Financial calculation box */}
                  <div className="bg-stone-50 rounded-2xl p-4 border border-stone-200 space-y-3">
                    <div className="flex justify-between items-center text-xs pb-2 border-b border-stone-200">
                      <span className="text-stone-500 font-bold uppercase tracking-wider text-[10px]">Tổng tiền vé:</span>
                      <span className="font-black text-sm text-stone-900 font-mono">
                        {editingDepositBooking.totalPrice.toLocaleString()}đ
                      </span>
                    </div>

                    {/* Deposit amount input */}
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-extrabold text-stone-700 flex items-center justify-between">
                        <span>💰 Khách đã đặt cọc (VNĐ):</span>
                        <span className="text-[10px] font-bold text-emerald-700 font-mono">
                          {Number(editDepositAmount || 0).toLocaleString()}đ
                        </span>
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          min={0}
                          step={10000}
                          max={editingDepositBooking.totalPrice}
                          value={editDepositAmount}
                          onChange={(e) => setEditDepositAmount(Number(e.target.value) || 0)}
                          placeholder="Nhập số tiền khách đã cọc..."
                          className="w-full px-3.5 py-2.5 bg-white border border-stone-300 rounded-xl font-mono text-sm font-extrabold text-stone-800 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-stone-400">
                          VNĐ
                        </span>
                      </div>

                      {/* Quick preset buttons */}
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        <button
                          type="button"
                          onClick={() => setEditDepositAmount(0)}
                          className="px-2 py-1 bg-stone-200 hover:bg-stone-300 text-stone-700 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                        >
                          Chưa cọc (0đ)
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditDepositAmount(200000)}
                          className="px-2 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                        >
                          200.000đ
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditDepositAmount(300000)}
                          className="px-2 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                        >
                          300.000đ
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditDepositAmount(Math.round(editingDepositBooking.totalPrice * 0.5))}
                          className="px-2 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                        >
                          50% ({Math.round(editingDepositBooking.totalPrice * 0.5).toLocaleString()}đ)
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditDepositAmount(editingDepositBooking.totalPrice)}
                          className="px-2 py-1 bg-blue-100 hover:bg-blue-200 text-blue-900 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                        >
                          Thu đủ 100% ({editingDepositBooking.totalPrice.toLocaleString()}đ)
                        </button>
                      </div>
                    </div>

                    {/* Remaining Calculation Preview */}
                    <div className="pt-2 border-t border-stone-200 flex justify-between items-center">
                      <div>
                        <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider block">
                          Số tiền còn phải thu:
                        </span>
                        <span className="text-[10px] text-stone-400">
                          (Tài xế/Phụ xe thu khi khách lên xe)
                        </span>
                      </div>
                      <div className="text-right">
                        {Math.max(0, editingDepositBooking.totalPrice - (Number(editDepositAmount) || 0)) <= 0 ? (
                          <span className="inline-block px-2 py-1 bg-emerald-100 text-emerald-800 font-extrabold text-xs rounded-lg">
                            ✓ ĐÃ THU ĐỦ 100%
                          </span>
                        ) : (
                          <span className="font-black text-base text-red-600 font-mono">
                            {Math.max(0, editingDepositBooking.totalPrice - (Number(editDepositAmount) || 0)).toLocaleString()}đ
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* LÁI XE & BIỂN SỐ XE PHỤ TRÁCH KHÁCH NÀY */}
                  <div className="bg-blue-50/70 rounded-2xl p-4 border border-blue-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-[11px] font-black text-blue-950 flex items-center gap-1.5 uppercase tracking-wide">
                        <Car className="w-4 h-4 text-blue-700" />
                        Phân Lái Xe & Xe Đón Khách
                      </label>
                      <span className="text-[10px] text-blue-700 font-medium">Chọn nhanh bên dưới hoặc tự điền</span>
                    </div>

                    {/* Quick selection chips for drivers */}
                    <div className="flex flex-wrap gap-1.5">
                      {drivers.map((dr, idx) => (
                        <button
                          key={`dr-chip-${dr.id || idx}`}
                          type="button"
                          onClick={() => {
                            setEditDriverName(dr.name);
                            setEditDriverPhone(dr.phone);
                            setEditVehiclePlate(dr.plate);
                          }}
                          className="px-2.5 py-1 bg-white hover:bg-blue-100 text-blue-900 border border-blue-300 rounded-lg text-[10px] font-bold transition-all shadow-2xs cursor-pointer text-left"
                        >
                          🚗 <strong>{dr.name}</strong> • {dr.plate}
                        </button>
                      ))}
                      {(editDriverName || editDriverPhone || editVehiclePlate) && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditDriverName("");
                            setEditDriverPhone("");
                            setEditVehiclePlate("");
                          }}
                          className="px-2 py-1 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-lg text-[10px] font-bold cursor-pointer"
                        >
                          Xóa phân công
                        </button>
                      )}
                    </div>

                    {/* Inputs for driver details */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                      <div>
                        <label className="text-[10px] font-bold text-stone-600 block mb-0.5">Tên lái xe</label>
                        <input
                          type="text"
                          value={editDriverName}
                          onChange={(e) => setEditDriverName(e.target.value)}
                          placeholder="VD: Anh Hải"
                          className="w-full px-3 py-2 bg-white border border-blue-200 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:border-blue-600"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-stone-600 block mb-0.5">SĐT lái xe</label>
                        <input
                          type="text"
                          value={editDriverPhone}
                          onChange={(e) => setEditDriverPhone(e.target.value)}
                          placeholder="VD: 0971050324"
                          className="w-full px-3 py-2 bg-white border border-blue-200 rounded-xl text-xs font-mono font-bold text-stone-800 focus:outline-none focus:border-blue-600"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-stone-600 block mb-0.5">Biển số xe</label>
                        <input
                          type="text"
                          value={editVehiclePlate}
                          onChange={(e) => setEditVehiclePlate(e.target.value)}
                          placeholder="VD: 26F-008.88"
                          className="w-full px-3 py-2 bg-white border border-blue-200 rounded-xl text-xs font-mono font-bold text-stone-800 focus:outline-none focus:border-blue-600"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Operator Notes Field */}
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-extrabold text-stone-700 flex items-center justify-between">
                      <span className="flex items-center gap-1">
                        <FileText className="w-3.5 h-3.5 text-stone-500" />
                        Ghi chú nội bộ nhà xe / Điều hành:
                      </span>
                    </label>
                    <textarea
                      rows={3}
                      value={editOperatorNotes}
                      onChange={(e) => setEditOperatorNotes(e.target.value)}
                      placeholder="VD: Đã nhận cọc 200k qua VCB. Lái xe đón khách tại BigC Thăng Long..."
                      className="w-full p-3 bg-white border border-stone-300 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                    />

                    {/* Quick template snippets */}
                    <div className="flex flex-wrap gap-1 pt-1">
                      {[
                        "Thu tiền tại xe",
                        "Đã cọc qua VCB",
                        "Đã cọc qua Momo",
                        "Khách dặn gọi trước 30p",
                        "Đã gửi vé qua Zalo",
                        "Đã báo lái xe"
                      ].map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => {
                            setEditOperatorNotes(prev => prev ? `${prev}, ${tag}` : tag);
                          }}
                          className="px-2 py-0.5 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-md text-[10px] font-medium transition-colors cursor-pointer"
                        >
                          + {tag}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Customer original notes (if any) */}
                  {editingDepositBooking.notes && (
                    <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs">
                      <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider block">
                        Ghi chú của khách khi đặt vé trực tuyến:
                      </span>
                      <p className="text-stone-700 italic mt-0.5 font-sans">
                        "{editingDepositBooking.notes}"
                      </p>
                    </div>
                  )}

                  {/* Action buttons */}
                  <div className="flex gap-2 pt-2">
                    <button
                      type="button"
                      disabled={isSavingDepositNotes}
                      onClick={handleSaveDepositAndNotes}
                      className="flex-1 bg-[#1b4332] hover:bg-emerald-800 text-white py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-colors shadow-md shadow-emerald-900/10 cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5"
                    >
                      <Check className="w-4 h-4" />
                      {isSavingDepositNotes ? "Đang lưu..." : "Lưu Thông Tin Lái Xe & Tiền Cọc"}
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingDepositBooking(null)}
                      className="px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 py-3 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                    >
                      Đóng
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TRIP LEVEL DRIVER ASSIGNMENT MODAL (BATCH ASSIGNMENT) */}
          {assigningTripGroup && (
            <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-[120] animate-fade-in text-left">
              <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-stone-200 flex flex-col animate-scale-up">
                <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white p-5 relative">
                  <button 
                    onClick={() => setAssigningTripGroup(null)}
                    className="absolute top-4 right-4 text-white/80 hover:text-white bg-white/10 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold cursor-pointer transition-colors"
                  >
                    ✕
                  </button>
                  <div className="flex items-center gap-2">
                    <Car className="w-5 h-5 text-blue-300" />
                    <span className="text-[10px] bg-blue-400 text-blue-950 font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                      PHÂN LÁI XE TOÀN BỘ CHUYẾN
                    </span>
                  </div>
                  <h3 className="text-lg font-black tracking-tight mt-2 text-white">
                    Chuyến {assigningTripGroup.departureTime} • {assigningTripGroup.routeSelection}
                  </h3>
                  <p className="text-blue-200 text-xs mt-0.5">
                    Áp dụng lái xe & biển số xe cho <strong>{assigningTripGroup.bookings.length} vé đặt</strong> ({assigningTripGroup.allSeatNumbers.length > 0 ? assigningTripGroup.allSeatNumbers.join(", ") : `${assigningTripGroup.totalSeats} khách`})
                  </p>
                </div>

                <div className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
                  {/* Select from fleet chips */}
                  <div className="space-y-2">
                    <label className="text-xs font-black text-stone-700 uppercase tracking-wide flex items-center justify-between">
                      <span>Chọn nhanh lái xe trong đội xe:</span>
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {drivers.map((dr, idx) => (
                        <button
                          key={`trip-dr-${dr.id || idx}`}
                          type="button"
                          onClick={() => {
                            setTripDriverName(dr.name);
                            setTripDriverPhone(dr.phone);
                            setTripVehiclePlate(dr.plate);
                          }}
                          className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                            tripDriverName === dr.name 
                              ? "bg-blue-100 border-blue-600 text-blue-950 ring-2 ring-blue-500/20" 
                              : "bg-stone-50 hover:bg-blue-50/50 border-stone-200 text-stone-800"
                          }`}
                        >
                          <div className="font-black text-xs text-blue-900 flex items-center justify-between">
                            <span>🚗 {dr.name}</span>
                            <span className="text-[10px] bg-white px-1.5 py-0.5 rounded border border-stone-200 font-mono">{dr.plate}</span>
                          </div>
                          <p className="text-[11px] text-stone-500 font-mono mt-0.5">SĐT: {dr.phone}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Manual / custom edit */}
                  <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200 space-y-3">
                    <span className="text-[11px] font-extrabold text-stone-700 block uppercase tracking-wider">
                      Hoặc tùy chỉnh thông tin tài xế chuyến:
                    </span>
                    <div className="space-y-2">
                      <div>
                        <label className="text-[10px] font-bold text-stone-600 block mb-0.5">Họ tên lái xe:</label>
                        <input
                          type="text"
                          value={tripDriverName}
                          onChange={(e) => setTripDriverName(e.target.value)}
                          placeholder="VD: Anh Hải"
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-bold text-stone-800 focus:outline-none focus:border-blue-600"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-[10px] font-bold text-stone-600 block mb-0.5">Số điện thoại:</label>
                          <input
                            type="text"
                            value={tripDriverPhone}
                            onChange={(e) => setTripDriverPhone(e.target.value)}
                            placeholder="VD: 0971050324"
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-800 focus:outline-none focus:border-blue-600"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-stone-600 block mb-0.5">Biển số xe:</label>
                          <input
                            type="text"
                            value={tripVehiclePlate}
                            onChange={(e) => setTripVehiclePlate(e.target.value)}
                            placeholder="VD: 26F-008.88"
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-800 focus:outline-none focus:border-blue-600"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* List of bookings to be updated */}
                  <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-200">
                    <span className="text-[10px] font-bold text-blue-900 uppercase block mb-1">
                      Danh sách {assigningTripGroup.bookings.length} khách trên chuyến sẽ được gán:
                    </span>
                    <div className="space-y-1 max-h-28 overflow-y-auto">
                      {assigningTripGroup.bookings.map((b, idx) => (
                        <div key={`trip-bk-item-${idx}`} className="text-[11px] text-stone-700 flex justify-between">
                          <span>• <strong>{b.passengerName}</strong> ({b.passengerPhone})</span>
                          <span className="font-mono text-emerald-800 font-bold">{b.seatNumbers?.join(", ") || `${b.seatCount || 1} chỗ`}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="flex gap-2 pt-2">
                    <button
                      type="button"
                      disabled={isSavingDepositNotes}
                      onClick={handleSaveTripDriver}
                      className="flex-1 bg-blue-700 hover:bg-blue-800 text-white py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-colors shadow-md shadow-blue-900/10 cursor-pointer disabled:opacity-50 flex items-center justify-center gap-1.5"
                    >
                      <Check className="w-4 h-4" />
                      {isSavingDepositNotes ? "Đang cập nhật..." : `Gán Cho Toàn Bộ ${assigningTripGroup.bookings.length} Vé`}
                    </button>
                    <button
                      type="button"
                      onClick={() => setAssigningTripGroup(null)}
                      className="px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 py-3 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                    >
                      Đóng
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
      {panelTab === "seatLock" && (
        /* TAB 2: SEAT LOCK CONTROL PANEL FOR TRIPS */
        <div className="bg-white rounded-2xl shadow-sm border border-stone-100 p-6 sm:p-8" id="seat_locker_manager_section">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-lg font-black text-stone-800 flex items-center gap-2">
              <Lock className="w-5 h-5 text-emerald-600" />
              Khóa Vé Chỗ Ngồi Cho Từng Chuyến Đi Cố Định
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              * Khách hàng đặt mua vé trực tiếp qua số điện thoại/Zalo, không thanh toán trên web? Quý nhà xe có thể tự chọn khóa vé theo từng lộ trình, ngày di chuyển và khung giờ cụ thể để khách online không thể click chọn giữ trùng!
            </p>

            {/* Selection Form for Seat Locking */}
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-4 mt-6 bg-stone-50 p-4 rounded-xl border border-stone-200">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-500 block uppercase">Loại dịch vụ xe</label>
                <select
                  value={lockService}
                  onChange={(e) => {
                    setLockService(e.target.value as any);
                  }}
                  className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-semibold focus:outline-none"
                >
                  <option value="limousine">Limousine (9 chỗ)</option>
                  <option value="shared_car">Xe Ghép (6 chỗ)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-500 block uppercase">Tuyến xuất phát</label>
                <select
                  value={lockFrom}
                  onChange={(e) => {
                    const val = e.target.value;
                    setLockFrom(val);
                    setLockTo(val === "Hà Nội" ? "Mộc Châu" : "Hà Nội");
                  }}
                  className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-semibold focus:outline-none"
                >
                  <option value="Hà Nội">Hà Nội</option>
                  <option value="Mộc Châu">Mộc Châu</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-500 block uppercase">Điểm đến</label>
                <div className="w-full px-2.5 py-1.5 bg-stone-200 border border-stone-200 rounded-lg text-xs font-semibold text-stone-600">
                  {lockTo}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-500 block uppercase">Chọn ngày đi xe</label>
                <input
                  type="date"
                  value={lockDate}
                  onChange={(e) => setLockDate(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-semibold focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-stone-500 block uppercase">Khung giờ xe xuất bến</label>
                <select
                  value={lockTime}
                  onChange={(e) => setLockTime(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-semibold focus:outline-none"
                >
                  {activeDepartureHours.map((h, idx) => (
                    <option key={`hour-opt-${h}-${idx}`} value={h}>{h}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* List of currently locked seats */}
            <div className="mt-6 p-4 bg-red-50 rounded-xl border border-red-100">
              <h4 className="text-xs font-bold text-red-900 uppercase mb-3">Ghế đang khóa offline ({blockedSeats.length})</h4>
              {blockedSeats.length > 0 ? (
                <div className="space-y-2">
                  {blockedSeats.map((bs, idx) => (
                    <div key={`blocked-${bs.seatId}-${bs.tripId}-${idx}`} className="flex flex-wrap justify-between items-center gap-2 text-xs bg-white p-3 rounded-lg border border-red-200 shadow-xs">
                      <div>
                        <span className="font-extrabold text-[#1b4332] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded-md text-[9px] mr-2">
                          {bs.tripId.includes("shared_car") ? "XE GHÉP 7 CHỖ" : "LIMOUSINE VIP"}
                        </span>
                        <span className="font-bold text-stone-700">
                          Giờ: <strong className="text-stone-900 font-mono">{bs.tripId.replace("shared_car_trip_custom_", "").replace("trip_custom_", "").replace("_", ":")}</strong> | Ngày: {bs.travelDate} | Ghế: {bs.seatId.toUpperCase().replace("S", "A")}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {bs.customerPhone && <span className="font-mono text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-100 font-bold">📞 {bs.customerPhone}</span>}
                        <button 
                          onClick={() => {
                            handleEditBlockedSeatFromList(bs);
                          }}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-[10px] font-extrabold uppercase transition cursor-pointer"
                        >
                          Sửa
                        </button>
                        <button 
                          onClick={() => {
                            onRemoveBlockedSeat(bs);
                          }}
                          className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white rounded-md text-[10px] font-extrabold uppercase transition cursor-pointer"
                        >
                          Mở khóa
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[10px] text-red-600">Không có ghế nào đang bị khóa.</p>
              )}
            </div>

            {/* Custom Input for Client Phone Number to block-lock seats */}
            <div className="mt-4 p-3 bg-emerald-50/50 border border-emerald-200/60 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 text-stone-900 shadow-xs max-w-sm sm:max-w-md mx-auto">
              <div className="text-left">
                <span className="text-xs font-bold text-stone-800 block">SĐT khách hàng đặt trực tiếp (tùy chọn)</span>
                <span className="text-[10px] text-stone-500 block sm:max-w-xs leading-normal">Nhập số điện thoại tại đây trước khi bấm chọn ghế để lưu SĐT vào bộ nhớ ghế khóa.</span>
              </div>
              <input
                type="text"
                placeholder="Ví dụ: 0971050324"
                value={lockPhone}
                onChange={(e) => setLockPhone(e.target.value)}
                className="px-3 py-1.5 bg-white border border-stone-200 rounded-lg text-xs font-bold font-mono text-stone-800 focus:outline-none focus:border-emerald-600 w-full sm:w-40 text-center"
              />
            </div>

            {/* Interactive VIP Limousine Interior Mockup */}
            <div className="mt-8 border border-stone-200 rounded-3xl p-5 sm:p-6 max-w-sm mx-auto bg-stone-50 shadow-sm">
              {/* Headboard section */}
              <div className="text-center font-sans">
                <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider">
                  {lockService === "limousine" ? "Đầu xe Limousine" : "Đầu xe SUV 7 Chỗ"}
                </span>
                <div className="w-24 h-5 bg-stone-300 rounded-full mx-auto mt-2 text-[9px] text-stone-600 flex items-center justify-center font-bold font-mono shadow-xs">
                  LÁI XE / CABIN
                </div>
              </div>

              {lockService === "limousine" ? (
                /* Grid 9 seats layout */
                <div className="mt-6 space-y-3.5">
                  {/* Row 1: Active cabin front row */}
                  <div className="grid grid-cols-2 gap-3 max-w-xs mx-auto">
                    {INITIAL_SEATS_TEMPLATE.slice(0, 2).map((seat) => renderSeatMapButton(seat, false))}
                  </div>

                  {/* Walkway corridor spacer */}
                  <div className="py-1 flex items-center justify-center">
                    <span className="text-[8px] uppercase tracking-wider font-extrabold text-stone-400 bg-stone-100 border border-stone-200/55 px-2.5 py-0.5 rounded-sm">LỐI ĐI HÀNH KHÁCH</span>
                  </div>

                  {/* VIP middle seats rows */}
                  <div className="grid grid-cols-2 gap-3 max-w-xs mx-auto">
                    {INITIAL_SEATS_TEMPLATE.slice(2, 6).map((seat) => renderSeatMapButton(seat, true))}
                  </div>

                  {/* Walkway corridor spacer 2 */}
                  <div className="py-1 flex items-center justify-center">
                    <span className="text-[8.5px] uppercase tracking-wider font-extrabold text-[#113022]/40">Hàng ghế tiêu chuẩn sau</span>
                  </div>

                  {/* Back standard seats row */}
                  <div className="grid grid-cols-3 gap-2.5 max-w-xs mx-auto pt-1">
                    {INITIAL_SEATS_TEMPLATE.slice(6, 9).map((seat) => renderSeatMapButton(seat, false))}
                  </div>
                </div>
              ) : (
                /* Grid 6 seats layout for Shared SUV */
                <div className="mt-6 space-y-3.5">
                  {/* Row 1: Cabin front row (Driver on Left, Seat A1 on Right) */}
                  <div className="grid grid-cols-2 gap-3 max-w-xs mx-auto">
                    <div className="border border-stone-200 bg-stone-200 text-stone-500 flex items-center justify-center text-[10px] font-bold rounded-xl h-20 font-sans uppercase">Lái xe</div>
                    {INITIAL_SEATS_SHARED.slice(0, 1).map((seat) => renderSeatMapButton(seat, false))}
                  </div>

                  {/* Space divisor */}
                  <div className="py-1 flex items-center justify-center">
                    <span className="text-[8px] uppercase tracking-wider font-extrabold text-stone-400 bg-stone-100 border border-stone-200/55 px-2.5 py-0.5 rounded-sm">HÀNG GHẾ 2</span>
                  </div>

                  {/* Row 2: 3 seats */}
                  <div className="grid grid-cols-3 gap-2.5 max-w-xs mx-auto">
                    {INITIAL_SEATS_SHARED.slice(1, 4).map((seat) => renderSeatMapButton(seat, true))}
                  </div>

                  {/* Space divisor 2 */}
                  <div className="py-1 flex items-center justify-center">
                    <span className="text-[8px] uppercase tracking-wider font-extrabold text-stone-400 bg-stone-100 border border-stone-200/55 px-2.5 py-0.5 rounded-sm">HÀNG GHẾ 3</span>
                  </div>

                  {/* Row 3: 2 seats */}
                  <div className="grid grid-cols-2 gap-3 max-w-xs mx-auto">
                    {INITIAL_SEATS_SHARED.slice(4, 6).map((seat) => renderSeatMapButton(seat, false))}
                  </div>
                </div>
              )}

              {/* Lock legends */}
              <div className="mt-6 pt-4 border-t border-stone-200 flex flex-col gap-2 text-[10px] text-stone-500">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 bg-indigo-600 border border-indigo-700 rounded-sm inline-block shadow-xs" />
                    <span className="font-semibold">Đã đặt online (Hiển thị SĐT)</span>
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 bg-red-600 border border-red-700 rounded-sm inline-block shadow-xs" />
                    <span className="font-semibold">Đã khóa giữ chỗ (Có SĐT)</span>
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 bg-white border border-stone-200 rounded-sm inline-block shadow-xs" />
                    <span className="font-semibold">Ghế trống</span>
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-6 text-center text-xs text-stone-500 max-w-md mx-auto leading-relaxed">
              <span className="font-bold text-amber-600 uppercase block mb-1">CẢNH BÁO CHO ĐIỀU HÀNH VIÊN</span>
              Việc bấm trực tiếp vào ô ghế sẽ khóa/mở khóa thực tế trên website cho chuyến đi vào lúc <strong>{lockTime} ngày {lockDate} ({lockFrom} ➔ {lockTo})</strong>. Hãy thận trọng trước mỗi thao tác giữ ghế!
            </div>
          </div>
        </div>
      )}
      {panelTab === "customers" && (
        <div className="bg-white rounded-2xl shadow-sm border border-stone-100 p-6 sm:p-8" id="customers_manager_section">
          <h3 className="text-xl font-black text-stone-900 mb-6">Quản lý khách hàng</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-stone-600 min-w-[500px]">
              <thead>
                <tr className="border-b">
                  <th className="p-3">SĐT</th>
                  <th className="p-3">Email</th>
                  <th className="p-3">Điểm</th>
                  <th className="p-3">Hành động</th>
                </tr>
              </thead>
              <tbody>
                {users.map((u, i) => (
                  <tr key={`user-row-${u.phone || i}-${i}`} className="border-b">
                    <td className="p-3 font-semibold text-stone-900">{u.phone}</td>
                    <td className="p-3">{u.email}</td>
                    <td className="p-3">{u.points || 0}</td>
                      <td className="p-3 text-red-600 font-bold cursor-pointer hover:underline" onClick={() => setUserToDelete(u)}>Hủy TK</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {panelTab === "overview" && (
        <div className="bg-white rounded-2xl shadow-sm border border-stone-100 p-6 sm:p-8" id="overview_manager_section">
          <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
            <h3 className="text-xl font-black text-stone-900">Tổng quan chuyến</h3>
            <input
              type="date"
              value={lockDate}
              onChange={(e) => setLockDate(e.target.value)}
              className="px-4 py-2 bg-stone-100 rounded-xl text-sm font-bold border border-stone-200"
            />
          </div>

          {[
            { label: "Chiều HN - Mộc Châu", route: "Hà Nội - Mộc Châu" },
            { label: "Chiều Mộc Châu - HN", route: "Mộc Châu - Hà Nội" }
          ].map((direction, idx) => (
            <div key={`dir-row-${direction.route || idx}-${idx}`} className="mb-8">
              <h4 className="text-lg font-bold text-stone-800 mb-4 border-b pb-2">{direction.label}</h4>
              
              <div className="mb-6">
                <h5 className="text-sm font-bold text-stone-600 mb-2">Xe Limousine (9 ghế)</h5>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                  {getOfficialSchedulesForRoute(direction.route.split(' - ')[0], direction.route.split(' - ')[1]).map((time, idx) => {
                    const bookedCount = bookings.filter(b => b.type === "limousine" && (b.status === "success" || b.status === "completed") && b.departureTime === time && b.travelDate === lockDate && (b.routeSelection === direction.route || b.routeSelection?.replace(' ➔ ', ' - ') === direction.route)).reduce((sum, b) => sum + (b.seatNumbers?.length || 0), 0);
                    const blockedCount = blockedSeats.filter(b => b.tripId === `trip_custom_${time.replace(':', '_')}` && b.travelDate === lockDate).length;
                    const total = 9;
                    return (
                      <div key={`limo-grid-${direction.route}-${time}-${idx}`} className={`p-3 rounded-lg border ${bookedCount + blockedCount >= total ? 'bg-red-50 border-red-100' : 'bg-emerald-50 border-emerald-100'}`}>
                        <p className="text-[10px] font-bold">{time}</p>
                        <p className="text-sm font-black">{bookedCount + blockedCount} / {total} ghế</p>
                      </div>
                    )
                  })}
                </div>
              </div>

              <div>
                <h5 className="text-sm font-bold text-stone-600 mb-2">Xe Ghép (6 ghế)</h5>
                <div className="grid grid-cols-3 md:grid-cols-6 lg:grid-cols-9 gap-2">
                  {getSharedCarSchedules().map((time, idx) => {
                    const bookedCount = bookings.filter(b => b.type === "shared_car" && (b.status === "success" || b.status === "completed") && b.departureTime === time && b.travelDate === lockDate && (b.routeSelection === direction.route || b.routeSelection?.replace(' ➔ ', ' - ') === direction.route)).reduce((sum, b) => sum + (b.seatNumbers?.length || 0), 0);
                    const blockedCount = blockedSeats.filter(b => b.tripId === `shared_car_trip_custom_${time.replace(':', '_')}` && b.travelDate === lockDate).length;
                    const total = 6;
                    return (
                      <div key={`shared-grid-${direction.route}-${time}-${idx}`} className={`p-2 rounded-lg border ${bookedCount + blockedCount >= total ? 'bg-red-50 border-red-100' : 'bg-sky-50 border-sky-100'}`}>
                        <p className="text-[9px] font-bold">{time}</p>
                        <p className="text-[11px] font-black">{bookedCount + blockedCount} / {total}</p>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {panelTab === "travelServices" && (
        <AccommodationComboManagement 
          accommodations={accommodations} 
          onUpdateAccommodations={onUpdateAccommodations}
          combos={combos}
          onUpdateCombos={onUpdateCombos}
        />
      )}
      {panelTab === "schedules" && (
        <div className="bg-white rounded-2xl shadow-sm border border-stone-100 p-6 sm:p-8" id="schedule_manager_section">
          <ScheduleManagement 
            limousineConfig={limousineConfig} 
            onUpdateLimousineConfig={onUpdateLimousineConfig} 
          />
        </div>
      )}
      {panelTab === "content" && (
        <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden" id="content_manager_section">
          <div className="flex border-b border-stone-100 bg-stone-50/50">
            <button
              onClick={() => setActiveContentTab("destinations")}
              className={`flex-1 py-4 flex items-center justify-center gap-2 text-xs font-black uppercase tracking-widest transition-all cursor-pointer ${
                activeContentTab === "destinations"
                  ? "bg-white text-emerald-800 border-b-2 border-emerald-600 shadow-sm"
                  : "text-stone-400 hover:text-stone-600"
              }`}
            >
              <MapPin className={`w-4 h-4 ${activeContentTab === "destinations" ? "text-emerald-600" : "text-stone-300"}`} />
              Khám phá Mộc Châu
            </button>
            <button
              onClick={() => setActiveContentTab("articles")}
              className={`flex-1 py-4 flex items-center justify-center gap-2 text-xs font-black uppercase tracking-widest transition-all cursor-pointer ${
                activeContentTab === "articles"
                  ? "bg-white text-emerald-800 border-b-2 border-emerald-600 shadow-sm"
                  : "text-stone-400 hover:text-stone-600"
              }`}
            >
              <Newspaper className={`w-4 h-4 ${activeContentTab === "articles" ? "text-emerald-600" : "text-stone-300"}`} />
              Cẩm nang du lịch
            </button>
          </div>

          <div className="p-6 sm:p-8">
            {activeContentTab === "destinations" ? (
              <DestinationManagement 
                destinations={destinations} 
                onUpdateDestinations={onUpdateDestinations} 
              />
            ) : (
              <ArticleManagement 
                articles={articles} 
                onUpdateArticles={onUpdateArticles} 
              />
            )}
          </div>
        </div>
      )}
      {panelTab === "pricing" && (
        <div className="bg-white rounded-2xl shadow-sm border border-stone-100 p-6 sm:p-8" id="pricing_manager_section">
          <PricingManagement limousineConfig={limousineConfig} onUpdateLimousineConfig={onUpdateLimousineConfig} sharedCarConfig={sharedCarConfig} onUpdateSharedCarConfig={onUpdateSharedCarConfig} />
        </div>
      )}
      {panelTab === "coupons" && (
        <div className="bg-white rounded-2xl shadow-sm border border-stone-100 p-6 sm:p-8" id="coupons_manager_section">
          <CouponManagement coupons={coupons} onUpdateCoupons={onUpdateCoupons} />
        </div>
      )}
      {panelTab === "locations" && (
        <div className="bg-white rounded-2xl shadow-sm border border-stone-100 p-6 sm:p-8" id="locations_manager_section">
          <LocationManagement locations={locations} onUpdateLocations={onUpdateLocations} />
        </div>
      )}

      {panelTab === "drivers" && (
        <div className="bg-white rounded-2xl shadow-sm border border-stone-100 p-6 sm:p-8" id="drivers_manager_section">
          <DriverManagement drivers={drivers} onUpdateDrivers={onUpdateDrivers} />
        </div>
      )}

      {panelTab === "reviews" && (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <ReviewManagement destinations={destinations} />
        </div>
      )}

      {(panelTab === "zaloCommunity" || activeModuleId === "community_zalo") && (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <ZaloCommunityManagement zaloGroups={zaloGroups} onUpdateZaloGroups={onUpdateZaloGroups} />
        </div>
      )}

      {/* Module: Đơn dịch vụ du lịch (Tour, Combo & Thuê xe) */}
      {activeModuleId === "service_orders" && <ServiceInquiryManagement />}
      {activeModuleId === "service_orders" && (
        <div className="bg-white rounded-2xl shadow-xs border border-stone-200 p-6 sm:p-8 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-stone-100 pb-4">
            <div>
              <h3 className="text-base font-black text-stone-900">Đơn Dịch Vụ Du Lịch & Combo Trải Nghiệm</h3>
              <p className="text-xs text-stone-500 mt-0.5">Yêu cầu đặt combo xe + homestay, phòng nghỉ dưỡng và tour trải nghiệm</p>
            </div>
            <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1 rounded-xl border border-emerald-200">
              Tổng cộng: {bookings.filter(b => b.type === "combo" || b.type === "private_charter").length} đơn
            </span>
          </div>

          <div className="space-y-3">
            {bookings.filter(b => b.type === "combo" || b.type === "private_charter").length > 0 ? (
              bookings.filter(b => b.type === "combo" || b.type === "private_charter").map((b, idx) => (
                <div key={b.id || idx} className="p-4 rounded-2xl border border-stone-200 bg-stone-50/60 hover:bg-white transition-all flex flex-wrap justify-between items-center gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono font-bold text-emerald-800 text-xs">{b.id}</span>
                      <span className="text-[10px] bg-amber-100 text-amber-900 font-black px-2 py-0.5 rounded-full uppercase">
                        {b.type === "combo" ? `Combo: ${b.accommodationName || "Homestay Mộc Châu"}` : "Thuê Xe Riêng"}
                      </span>
                    </div>
                    <p className="text-xs text-stone-700 font-sans">
                      Khách hàng: <strong>{b.passengerName}</strong> (SĐT: <a href={`tel:${b.passengerPhone}`} className="text-emerald-700 font-mono font-bold">{b.passengerPhone}</a>)
                    </p>
                    <p className="text-[11px] text-stone-500">
                      Ngày khởi hành: {b.travelDate} • Giờ: {b.departureTime || "07:00"} • Điểm đón: {b.pickupPoint || "Hà Nội"}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-base font-black text-stone-900 font-mono block">{(b.totalPrice || 0).toLocaleString()} đ</span>
                    <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full inline-block mt-1 ${
                      b.status === "completed" || b.status === "success" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                    }`}>
                      {b.status === "completed" || b.status === "success" ? "Đã xác nhận" : "Chờ điều hành"}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-12 text-center text-stone-400 text-xs italic">
                Chưa có đơn dịch vụ combo nào.
              </div>
            )}
          </div>
        </div>
      )}

      {activeModuleId === "site_appearance" && <SiteContentStudio />}

      {/* Module: Nhà hàng & Ẩm thực */}
      {activeModuleId === "restaurants_culinary" && (
        <RestaurantManagement />
      )}

      {/* Module: Mùa hoa & Trải nghiệm */}
      {activeModuleId === "flower_seasons" && (
        <FlowerSeasonManagement />
      )}

      {/* Module: Trợ lý AI */}
      {activeModuleId === "ai_assistant" && (
        <AIAssistantManagement />
      )}

      {/* Module: Thời tiết Live */}
      {activeModuleId === "live_weather" && (
        <LiveWeatherManagement />
      )}

      {/* Module: Mạng lưới Đối tác */}
      {activeModuleId === "partner_network" && (
        <PartnerManagement />
      )}

      {/* Module: Hoa hồng & Công nợ */}
      {activeModuleId === "commissions_debt" && (
        <CommissionDebtManagement />
      )}

      {/* Module: Thống kê & Tăng trưởng */}
      {activeModuleId === "growth_analytics" && (
        <GrowthAnalytics bookings={bookings} />
      )}

      {/* Module: Taxi & Xe du lịch 4-7-9-16 chỗ */}
      {activeModuleId === "taxi_tourist_cars" && (
        <TaxiFleetManagement />
      )}

      {/* Module: Cho thuê xe máy */}
      {activeModuleId === "motorbike_rental" && (
        <MotorbikeManagement />
      )}

      {/* Module: Cấu hình & Bảo mật */}
      {activeModuleId === "security_config" && (
        <SecurityConfigManagement />
      )}

        </main>
      </div>

      {userToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <h3 className="text-xl font-bold text-stone-900 mb-2">Xác nhận</h3>
            <p className="text-stone-600 mb-6">Bạn có chắc chắn muốn xóa tài khoản này không? Hành động này không thể hoàn tác.</p>
            <div className="flex justify-end gap-3">
              <button 
                onClick={() => setUserToDelete(null)}
                className="px-4 py-2 font-semibold text-stone-500 hover:bg-stone-100 rounded-xl transition-colors cursor-pointer"
              >
                Không
              </button>
              <button 
                onClick={() => {
                  import("../lib/firebaseUtils").then(({ getLocalList, setLocalList }) => {
                    const current = getLocalList<any>("users", []);
                    const filtered = current.filter(user => user.id !== userToDelete.id);
                    setLocalList("users", filtered);
                    window.dispatchEvent(new Event("xedimocchau_db_update"));
                  });
                  import("../firebase").then(({ auth, db }) => {
                    import("firebase/firestore").then(({ doc, deleteDoc }) => {
                      if (auth.currentUser) {
                        deleteDoc(doc(db, "users", userToDelete.id)).catch(console.error);
                      }
                    });
                  });
                  alert("Đã xóa tài khoản thành công!");
                  setUserToDelete(null);
                }}
                className="px-4 py-2 font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl transition-colors cursor-pointer"
              >
                Có
              </button>
            </div>
          </div>
        </div>
      )}

      {selectedSeatForEdit && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 w-full max-w-lg shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] font-black tracking-widest text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full uppercase">
                  {getOnlineBookingForSeat(selectedSeatForEdit.seat.number) ? "VÉ ĐẶT ONLINE" : getBlockedItemForSeat(selectedSeatForEdit.seat.id) ? "GHẾ ĐANG KHÓA OFFLINE" : "GHẾ TRỐNG"}
                </span>
                <h3 className="text-xl font-black text-[#1b4332] mt-1">
                  Thông tin Ghế {selectedSeatForEdit.seat.number} {selectedSeatForEdit.isVip ? "(VIP)" : ""}
                </h3>
                <p className="text-[11px] text-stone-500 font-bold font-mono mt-0.5">
                  Xe: {lockService === "limousine" ? "Limousine 9 chỗ" : "Xe ghép 7 chỗ"} • Lộ trình: {lockFrom} ➔ {lockTo} • Giờ: {lockTime} • Ngày: {lockDate}
                </p>
              </div>
              <button 
                onClick={() => setSelectedSeatForEdit(null)}
                className="p-1.5 hover:bg-stone-100 rounded-full transition-colors text-stone-400 hover:text-stone-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Passenger Name Field */}
              <div>
                <label className="text-[10px] font-black text-stone-500 uppercase block tracking-wider mb-1">Khách hàng</label>
                <div className="relative">
                  <User className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    placeholder="Nhập tên khách hàng..."
                    value={seatPassengerName}
                    onChange={(e) => setSeatPassengerName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 border border-stone-200 rounded-xl text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-bold"
                  />
                </div>
              </div>

              {/* Passenger Phone Field */}
              <div>
                <label className="text-[10px] font-black text-stone-500 uppercase block tracking-wider mb-1">Số điện thoại</label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    placeholder="Nhập SĐT..."
                    value={seatPassengerPhone}
                    onChange={(e) => setSeatPassengerPhone(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 border border-stone-200 rounded-xl text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono font-bold"
                  />
                </div>
              </div>

              {/* Pickup Point Field */}
              <div>
                <label className="text-[10px] font-black text-stone-500 uppercase block tracking-wider mb-1">Điểm đón</label>
                <input
                  type="text"
                  placeholder="Nhập điểm đón..."
                  value={seatPickupPoint}
                  onChange={(e) => setSeatPickupPoint(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-xl text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />
                
                {((locations || []).filter(l => l.type === "pickup" && l.city === lockFrom && (l.serviceType === "both" || l.serviceType === (lockService === "limousine" ? "limousine" : "shared"))).length > 0) && (
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    <span className="text-[9px] text-stone-400 self-center mr-1 font-semibold">Gợi ý:</span>
                    {(locations || [])
                      .filter(l => l.type === "pickup" && l.city === lockFrom && (l.serviceType === "both" || l.serviceType === (lockService === "limousine" ? "limousine" : "shared")))
                      .slice(0, 5)
                      .map((p) => (
                        <button
                          key={`pick-sug-${p.id}`}
                          type="button"
                          onClick={() => setSeatPickupPoint(p.name)}
                          className="px-2 py-0.5 bg-stone-100 hover:bg-emerald-50 hover:text-emerald-700 text-stone-600 border border-stone-200 rounded text-[9px] font-bold transition-colors cursor-pointer"
                        >
                          {p.name}
                        </button>
                      ))}
                  </div>
                )}
              </div>

              {/* Dropoff Point Field */}
              <div>
                <label className="text-[10px] font-black text-stone-500 uppercase block tracking-wider mb-1">Điểm trả</label>
                <input
                  type="text"
                  placeholder="Nhập điểm trả..."
                  value={seatDropoffPoint}
                  onChange={(e) => setSeatDropoffPoint(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-200 rounded-xl text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />

                {((locations || []).filter(l => l.type === "dropoff" && l.city === lockTo && (l.serviceType === "both" || l.serviceType === (lockService === "limousine" ? "limousine" : "shared"))).length > 0) && (
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    <span className="text-[9px] text-stone-400 self-center mr-1 font-semibold">Gợi ý:</span>
                    {(locations || [])
                      .filter(l => l.type === "dropoff" && l.city === lockTo && (l.serviceType === "both" || l.serviceType === (lockService === "limousine" ? "limousine" : "shared")))
                      .slice(0, 5)
                      .map((d) => (
                        <button
                          key={`drop-sug-${d.id}`}
                          type="button"
                          onClick={() => setSeatDropoffPoint(d.name)}
                          className="px-2 py-0.5 bg-stone-100 hover:bg-emerald-50 hover:text-emerald-700 text-stone-600 border border-stone-200 rounded text-[9px] font-bold transition-colors cursor-pointer"
                        >
                          {d.name}
                        </button>
                      ))}
                  </div>
                )}
              </div>

              {/* Notes / Ghi chú */}
              <div>
                <label className="text-[10px] font-black text-stone-500 uppercase block tracking-wider mb-1">Ghi chú</label>
                <textarea
                  placeholder="Ghi chú thêm thông tin..."
                  value={seatNotes}
                  onChange={(e) => setSeatNotes(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 border border-stone-200 rounded-xl text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />
              </div>
            </div>

            {/* Actions Footer */}
            <div className="pt-2 border-t border-stone-100 flex flex-wrap justify-between items-center gap-3">
              <div>
                {!getOnlineBookingForSeat(selectedSeatForEdit.seat.number) && getBlockedItemForSeat(selectedSeatForEdit.seat.id) && (
                  <button
                    type="button"
                    disabled={isUpdatingSeat}
                    onClick={handleUnlockSeatDirect}
                    className="px-4 py-2 text-red-600 hover:bg-red-50 border border-red-200 rounded-xl text-xs font-bold transition-colors cursor-pointer disabled:opacity-50"
                  >
                    Mở khóa ghế
                  </button>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  disabled={isUpdatingSeat}
                  onClick={() => setSelectedSeatForEdit(null)}
                  className="px-4 py-2 text-stone-500 hover:bg-stone-50 border border-stone-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  Đóng
                </button>
                <button
                  type="button"
                  disabled={isUpdatingSeat}
                  onClick={handleSaveSeatEdit}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition-colors cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                >
                  {isUpdatingSeat ? (
                    <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : null}
                  Cập nhật & Lưu
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
