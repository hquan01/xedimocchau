# HƯỚNG DẪN NHẬP ZIP VÀO GOOGLE AI STUDIO

CÓ 2 GÓI:

1. `QT_Limousine_ma_nguon_da_sua.zip`: mã nguồn đầy đủ, nhập thành dự án mới để kiểm tra. ZIP này được sửa trên bản ZIP người dùng gửi và KHÔNG tự động cập nhật GitHub/Vercel/Firebase.
2. `QT_Limousine_ban_va_cho_du_an_hien_tai.zip`: chỉ chứa các file mới/sửa (kèm prompt). Thích hợp để Google AI Studio ĐỐI CHIẾU với mã nguồn GitHub main mới. KHÔNG sao chép đè toàn bộ một cách mù quáng.

LÀM THEO THỨ TỰ:

A. Sao lưu GitHub và xuất bản sao dữ liệu Firestore trước khi thay đổi.
B. Google AI Studio: mở một dự án thử nghiệm, tải ZIP mã nguồn đầy đủ; hoặc giải nén bản vá và đưa từng file vào ngữ cảnh AI Studio. Đọc `PROMPT_GOOGLE_AI_STUDIO.txt` rồi yêu cầu hợp nhất các sửa đổi với nhánh mới nhất.
C. Trong môi trường có mạng: `npm ci`, `npm run lint`, `npm run build`.
D. Kiểm thử Firebase Security Rules qua Emulator cho: khách đặt vé không đăng nhập, khách đăng nhập, Admin, khách báo cọc, thêm/sửa/xóa dữ liệu.
E. Kiểm tra Firestore RULES đang dùng thực tế. KHÔNG tự deploy file rules trong ZIP lên production nếu chưa kiểm thử tương thích.
F. Thử các thao tác Admin thêm, sửa, xóa bản ghi test; kiểm tra lại sau refresh, máy khác; không xóa dữ liệu thật.
G. Kiểm tra khách đặt vé thành công rồi mới thấy QR; khách báo cọc xong trạng thái vẫn chờ; Admin kiểm tra sao kê và duyệt; không tự duyệt từ nút khách.
H. Chỉ khi test hoàn tất mới merge vào main một lần, đợi Vercel tự triển khai. Nếu quota có giới hạn, tránh tạo nhiều commit/push liên tiếp.

LƯU Ý: Tải lên Google AI Studio bằng ZIP KHÔNG bảo đảm vượt qua quota của Google AI Studio hay Vercel. Nó chỉ giúp chuẩn bị một bộ mã nguồn sửa sẵn và giảm việc lặp lại chỉnh sửa trong phiên chat AI.

Điểm chưa hoàn thành được liệt kê trong `BAO_CAO_SUA_LOI_VA_GIOI_HAN.md`.
