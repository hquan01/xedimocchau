# BÁO CÁO SỬA LỖI – QT LIMOUSINE / MỘC CHÂU TRAVEL

Ngày: 05/11/2026. Đầu vào: `xe-đi-mộc-châu (4).zip` do người dùng tải lên. Đây KHÔNG phải GitHub main mới nhất.

## Các thay đổi đã thực hiện trong mã nguồn ZIP

1. Đồng bộ nhận diện quyền quản trị giữa đăng nhập giao diện và Firestore: custom claim Firebase hoặc email chủ tài khoản **đã xác minh qua Firebase**; không lấy role localStorage làm chứng cứ quyền Admin.
2. Cấp 10 điểm hội viên MỚI một lần theo Firebase UID bằng transaction; không tự cấp bù điểm cho tài khoản cũ chưa xác minh lịch sử.
3. Phân biệt việc Firebase Auth đăng nhập thành công với việc hồ sơ Firestore đang lỗi; xử lý lỗi có lời giải thích.
4. Bỏ tự ghi dữ liệu mẫu vào Firestore khi các collection combo, lưu trú, bài viết, điểm đến, coupon trống; xóa hết vẫn là trạng thái hợp lệ.
5. Bỏ một số thao tác báo đã lưu/xóa thành công khi Firestore từ chối; chỉ mở bước QR sau khi lưu đơn thành công.
6. Thêm hook lưu cloud cho nhà hàng, mùa hoa, đối tác, đội taxi, xe máy, danh sách yêu cầu nội bộ, FAQ AI; giữ dữ liệu local cũ đến khi Admin chủ động chỉnh sửa. Firestore `admin_collections` chỉ cho Admin đọc/ghi.
7. Bảo vệ người dùng trước quyền Firestore `allow read, write: if true` của ZIP gốc. Tạo rules phân vai, hạn chế đọc thông tin cá nhân, và chỉ cho Admin thao tác Quản lý.
8. Tách báo đã chuyển cọc sang collection `payment_reports`: khách tạo thông báo, Admin đọc; không được tự xác nhận tiền. Admin thấy nhãn báo cọc trên đơn đang chờ.
9. Sửa ngày mặc định cũ và tránh dùng email khách bịa đặt. Không lưu mật khẩu mới hoặc quyền Admin vào hồ sơ Firestore.
10. Mỗi đơn đã được Admin xác nhận +1 điểm qua transaction, chống cộng hai lần bằng booking ID; lịch sử điểm không còn mặc định hiển thị +5 điểm/đơn.
11. Sửa đồng bộ thêm/xóa nhóm Zalo để chỉ báo thành công sau khi Firebase xác nhận, tránh dữ liệu tự phục hồi sau xóa.

## Chức năng còn yêu cầu kiểm thử hoặc hoàn thiện

- Môi trường này không truy cập Firebase Production, Firebase Rules đã deploy, tài khoản Admin/khách thực, log Vercel hoặc cổng thanh toán ngân hàng. Không xác nhận website Production đã sửa.
- Cài đặt thư viện bằng `npm ci --offline` thất bại do npm cache thiếu tarball. **Chưa chạy được `npm run lint`, `npm run build` hay Firebase Emulator.** Kiểm tra cú pháp TypeScript/TSX với TypeScript 5.8.3: 84 file, 0 lỗi cú pháp.
- Một số module khác (cảnh báo đường sá, cấu hình bảo mật PIN, nội dung công khai của nhà hàng, một số bảng mẫu) vẫn có chức năng localStorage hoặc dữ liệu tham khảo. Phải rà soát theo nhu cầu trước khi xuất bản.
- Voucher và quy đổi điểm vẫn cần nghiệp vụ xác minh giá/điều kiện **phía máy chủ** để chống việc chỉnh dữ liệu trên trình duyệt. Trong quy trình thủ công hiện tại, Admin phải kiểm tra giá, điểm và ưu đãi trước khi xác nhận vé.
- Nhận biết Admin qua email đã xác minh là phương án tương thích tạm thời. Để vận hành dài hạn, nên chuyển hoàn toàn sang Firebase custom claims do server cấp, có quy trình cấp/quản lý riêng.
- Khách chưa đăng nhập được tạo đơn; phần theo dõi đơn cũ trên trình duyệt khác cần tra cứu có xác minh riêng, không mở đọc toàn bộ bookings.
- `payment_reports` không có xác minh giao dịch ngân hàng; đây là điều người dùng yêu cầu, tiền cọc 50% vẫn do Admin đối chiếu thủ công.
- Nên bật Firebase App Check và chống spam ở production cho báo cọc/yêu cầu dịch vụ/cộng đồng; không thêm dịch vụ trả phí hoặc gateway thanh toán.
- `firestore.rules` là phương án để REVIEW, không được đè lên Production khi chưa dùng Emulator để test cùng dữ liệu thực / backup.
- Cần kiểm tra giờ chạy và thông tin vé với dữ liệu nhà xe. Không tạo giờ/giá/ngày không có thật.
- QUAN TRỌNG: Các file ZIP này bắt đầu từ ZIP upload, **cũ hơn nhánh GitHub main đã cập nhật**. Nếu Google AI Studio đang nối GitHub: so sánh và chỉ lấy các bản vá còn cần, không được ghi đè nhánh main bằng toàn bộ ZIP.

## Test tĩnh đã thực hiện

- 84 file TypeScript/TSX: 0 lỗi cú pháp.
- Không còn phép dùng `allow read, write: if true` đối với người dùng, đơn, cấu hình và voucher trong rules đề xuất. Các collection nội dung công khai vẫn `allow read: if true` là có chủ đích.
- Kiểm tra các module cloud không còn tự ghi dữ liệu localStorage mỗi lần state thay đổi.
- Kiểm tra ZIP sau tạo bằng CRC zipfile; kiểm tra mỗi đường dẫn an toàn.

## Danh sách 24 file được sửa hoặc bổ sung so với ZIP gốc

- `firestore.rules`
- `src/App.tsx`
- `src/components/AuthModal.tsx`
- `src/components/ComboBooking.tsx`
- `src/components/CustomerDashboard.tsx`
- `src/components/LimousineBooking.tsx`
- `src/components/OperatorPanel.tsx`
- `src/components/PaymentModal.tsx`
- `src/components/SharedCarBooking.tsx`
- `src/components/operator/AIAssistantManagement.tsx`
- `src/components/operator/FlowerSeasonManagement.tsx`
- `src/components/operator/MotorbikeManagement.tsx`
- `src/components/operator/PartnerManagement.tsx`
- `src/components/operator/RestaurantManagement.tsx`
- `src/components/operator/TaxiFleetManagement.tsx`
- `src/components/operator/ZaloCommunityManagement.tsx`
- `src/hooks/useAdminCloudList.ts`
- `src/hooks/useFirebaseSync.ts`
- `src/lib/adminAccess.ts`
- `src/lib/firebaseUtils.ts`
- `src/lib/memberProfile.ts`
- `src/lib/siteContent.ts`
- `src/types.ts`
- `storage.rules`
